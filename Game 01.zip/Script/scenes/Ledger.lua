-- [ts]: Ledger.ts
local ____lualib = require("lualib_bundle") -- 1
local __TS__Class = ____lualib.__TS__Class -- 1
local __TS__SetDescriptor = ____lualib.__TS__SetDescriptor -- 1
local ____exports = {} -- 1
local ____Dora = require("Dora") -- 2
local Color = ____Dora.Color -- 2
local DrawNode = ____Dora.DrawNode -- 2
local Node = ____Dora.Node -- 2
local Vec2 = ____Dora.Vec2 -- 2
local ____State = require("Script.core.State") -- 3
local state = ____State.state -- 3
local ____Viewport = require("Script.core.Viewport") -- 4
local DESIGN_WIDTH = ____Viewport.DESIGN_WIDTH -- 4
local DESIGN_HEIGHT = ____Viewport.DESIGN_HEIGHT -- 4
local ____UI = require("Script.core.UI") -- 5
local drawRoundRect = ____UI.drawRoundRect -- 5
local fillRect = ____UI.fillRect -- 5
local makeLabel = ____UI.makeLabel -- 5
local setLabelColor = ____UI.setLabelColor -- 5
local C_TEXT = Color(236, 233, 255, 255) -- 7
local C_DIM = Color(158, 154, 184, 255) -- 8
local C_GREEN = Color(96, 222, 140, 255) -- 9
local C_RED = Color(236, 106, 108, 255) -- 10
local C_PANEL = Color(12, 12, 26, 240) -- 11
local C_GLOW = Color(120, 102, 220, 150) -- 12
local STAT_LABEL = { -- 14
	courage = "勇气", -- 15
	hope = "希望", -- 16
	trust = "信任", -- 17
	anxiety = "焦虑", -- 18
	selfDoubt = "自我否定", -- 19
	guilt = "愧疚" -- 20
} -- 20
____exports.LedgerPanel = __TS__Class() -- 32
local LedgerPanel = ____exports.LedgerPanel -- 32
LedgerPanel.name = "LedgerPanel" -- 32
function LedgerPanel.prototype.____constructor(self) -- 45
	self.root = Node() -- 33
	self.bars = {} -- 38
	self.x = 0 -- 42
	self.targetX = 0 -- 43
	self.panelW = DESIGN_WIDTH * 0.6 -- 46
	self.pl = DESIGN_WIDTH / 2 - self.panelW -- 47
	self.x = self.panelW -- 48
	self.targetX = self.panelW -- 49
	self.root.x = self.x -- 50
	self.bg = DrawNode() -- 51
	self.fills = DrawNode() -- 52
	self.bg:addTo(self.root) -- 53
	self.fills:addTo(self.root) -- 54
end -- 45
function LedgerPanel.prototype.mount(self, host) -- 66
	self.root:addTo(host) -- 67
end -- 66
function LedgerPanel.prototype.dispose(self) -- 70
	self.root:removeFromParent() -- 71
end -- 70
function LedgerPanel.prototype.open(self) -- 74
	self.targetX = 0 -- 75
end -- 74
function LedgerPanel.prototype.close(self) -- 78
	self.targetX = self.panelW -- 79
end -- 78
function LedgerPanel.prototype.toggle(self) -- 82
	if self.isOpen then -- 82
		self:close() -- 83
	else -- 83
		self:open() -- 84
	end -- 84
end -- 82
function LedgerPanel.prototype.addLabel(self, text, size, color, x, y, ax) -- 87
	local l = makeLabel(text, size, color) -- 88
	if l then -- 88
		l.position = Vec2(x, y) -- 90
		l.anchor = Vec2(ax, 0.5) -- 91
		l:addTo(self.root) -- 92
	end -- 92
	return l -- 94
end -- 87
function LedgerPanel.prototype.addBar(self, key, kind, y) -- 97
	local pr = DESIGN_WIDTH / 2 -- 98
	local name = self:addLabel( -- 99
		STAT_LABEL[key], -- 99
		19, -- 99
		C_TEXT, -- 99
		self.pl + 26, -- 99
		y, -- 99
		0 -- 99
	) -- 99
	local value = self:addLabel( -- 100
		STAT_LABEL[key] .. " 0/100", -- 100
		17, -- 100
		C_DIM, -- 100
		pr - 26, -- 100
		y, -- 100
		1 -- 100
	) -- 100
	local barW = self.panelW - 52 -- 101
	fillRect( -- 102
		self.bg, -- 102
		self.pl + 26, -- 102
		y - 18, -- 102
		barW, -- 102
		12, -- 102
		Color(32, 30, 54, 255) -- 102
	) -- 102
	if name and value then -- 102
		local ____self_bars_0 = self.bars -- 102
		____self_bars_0[#____self_bars_0 + 1] = { -- 104
			key = key, -- 104
			kind = kind, -- 104
			y = y - 18, -- 104
			name = name, -- 104
			value = value, -- 104
			display = state:get(key) -- 104
		} -- 104
	end -- 104
end -- 97
function LedgerPanel.prototype.build(self) -- 108
	local halfH = DESIGN_HEIGHT / 2 -- 109
	local pr = DESIGN_WIDTH / 2 -- 110
	local cx = (self.pl + pr) / 2 -- 111
	local top = halfH -- 112
	drawRoundRect( -- 114
		self.bg, -- 114
		self.pl + 8, -- 114
		-halfH + 8, -- 114
		self.panelW - 16, -- 114
		DESIGN_HEIGHT - 16, -- 114
		22, -- 114
		C_PANEL, -- 114
		2, -- 114
		C_GLOW -- 114
	) -- 114
	fillRect( -- 115
		self.bg, -- 115
		self.pl + 8, -- 115
		-halfH + 24, -- 115
		5, -- 115
		DESIGN_HEIGHT - 48, -- 115
		C_GLOW -- 115
	) -- 115
	self:addLabel( -- 117
		"心灵总账本", -- 117
		32, -- 117
		C_TEXT, -- 117
		cx, -- 117
		top - 40, -- 117
		0.5 -- 117
	) -- 117
	self:addLabel( -- 118
		"定期盘点·动态平衡", -- 118
		16, -- 118
		C_DIM, -- 118
		cx, -- 118
		top - 66, -- 118
		0.5 -- 118
	) -- 118
	self:addLabel( -- 120
		"💎 心灵资产", -- 120
		22, -- 120
		C_GREEN, -- 120
		self.pl + 26, -- 120
		top - 98, -- 120
		0 -- 120
	) -- 120
	local assetKeys = {"courage", "hope", "trust"} -- 121
	do -- 121
		local i = 0 -- 122
		while i < 3 do -- 122
			self:addBar(assetKeys[i + 1], "asset", top - 130 - i * 32) -- 122
			i = i + 1 -- 122
		end -- 122
	end -- 122
	self:addLabel( -- 124
		"🩹 心灵负债", -- 124
		22, -- 124
		C_RED, -- 124
		self.pl + 26, -- 124
		top - 232, -- 124
		0 -- 124
	) -- 124
	local liabKeys = {"anxiety", "selfDoubt", "guilt"} -- 125
	do -- 125
		local i = 0 -- 126
		while i < 3 do -- 126
			self:addBar(liabKeys[i + 1], "liability", top - 264 - i * 32) -- 126
			i = i + 1 -- 126
		end -- 126
	end -- 126
	self:addLabel( -- 128
		"📈 净资产", -- 128
		22, -- 128
		C_TEXT, -- 128
		self.pl + 26, -- 128
		top - 366, -- 128
		0 -- 128
	) -- 128
	self.netLabel = self:addLabel( -- 130
		"0", -- 130
		44, -- 130
		C_GREEN, -- 130
		cx, -- 130
		top - 404, -- 130
		0.5 -- 130
	) -- 130
	self.arrowLabel = self:addLabel( -- 131
		"↓", -- 131
		30, -- 131
		C_RED, -- 131
		cx + 70, -- 131
		top - 404, -- 131
		0.5 -- 131
	) -- 131
	self.statusLabel = self:addLabel( -- 132
		"", -- 132
		16, -- 132
		C_DIM, -- 132
		cx, -- 132
		top - 436, -- 132
		0.5 -- 132
	) -- 132
	self:addLabel( -- 134
		"目标不是零负债，而是资产>负债，维持心灵动态平衡", -- 134
		14, -- 134
		C_DIM, -- 134
		cx, -- 134
		-halfH + 26, -- 134
		0.5 -- 134
	) -- 134
end -- 108
function LedgerPanel.prototype.update(self, dt) -- 137
	if self.x ~= self.targetX then -- 137
		local speed = self.panelW / 0.28 -- 139
		local step = speed * dt -- 140
		local diff = self.targetX - self.x -- 141
		if math.abs(diff) <= step then -- 141
			self.x = self.targetX -- 142
		else -- 142
			self.x = self.x + (diff > 0 and step or -step) -- 143
		end -- 143
		self.root.x = self.x -- 144
	end -- 144
	do -- 144
		local i = 0 -- 147
		while i < #self.bars do -- 147
			local b = self.bars[i + 1] -- 148
			local target = state:get(b.key) -- 149
			b.display = b.display + (target - b.display) * math.min(1, dt * 4) -- 150
			if math.abs(target - b.display) < 0.5 then -- 150
				b.display = target -- 151
			end -- 151
			b.value.text = ((STAT_LABEL[b.key] .. " ") .. tostring(math.floor(b.display + 0.5))) .. "/100" -- 152
			i = i + 1 -- 147
		end -- 147
	end -- 147
	self.fills:clear() -- 155
	local barW = self.panelW - 52 -- 156
	do -- 156
		local i = 0 -- 157
		while i < #self.bars do -- 157
			local b = self.bars[i + 1] -- 158
			local w = math.max(0, b.display / 100 * barW) -- 159
			local color = b.kind == "asset" and C_GREEN or C_RED -- 160
			fillRect( -- 161
				self.fills, -- 161
				self.pl + 26, -- 161
				b.y, -- 161
				w, -- 161
				12, -- 161
				color -- 161
			) -- 161
			fillRect( -- 162
				self.fills, -- 162
				self.pl + 26, -- 162
				b.y + 9, -- 162
				w, -- 162
				3, -- 162
				Color(255, 255, 255, 42) -- 162
			) -- 162
			i = i + 1 -- 157
		end -- 157
	end -- 157
	local assets = 0 -- 165
	local liab = 0 -- 166
	do -- 166
		local i = 0 -- 167
		while i < #self.bars do -- 167
			if self.bars[i + 1].kind == "asset" then -- 167
				assets = assets + self.bars[i + 1].display -- 168
			else -- 168
				liab = liab + self.bars[i + 1].display -- 169
			end -- 169
			i = i + 1 -- 167
		end -- 167
	end -- 167
	local net = assets - liab -- 171
	local netColor = net >= 0 and C_GREEN or C_RED -- 172
	if self.netLabel then -- 172
		self.netLabel.text = "" .. tostring(math.floor(net + 0.5)) -- 174
		setLabelColor(self.netLabel, netColor) -- 175
	end -- 175
	if self.arrowLabel then -- 175
		self.arrowLabel.text = net >= 0 and "↑" or "↓" -- 178
		setLabelColor(self.arrowLabel, netColor) -- 179
	end -- 179
	if self.statusLabel then -- 179
		self.statusLabel.text = net < 0 and "⚠️ 资不抵债，心灵需要疗愈" or "✓ 心灵健康运转中" -- 182
		setLabelColor(self.statusLabel, netColor) -- 183
	end -- 183
end -- 137
__TS__SetDescriptor( -- 137
	LedgerPanel.prototype, -- 137
	"isOpen", -- 137
	{get = function(self) -- 137
		return self.targetX < self.panelW * 0.5 -- 63
	end}, -- 63
	true -- 63
) -- 63
return ____exports -- 63