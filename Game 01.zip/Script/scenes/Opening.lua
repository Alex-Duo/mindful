-- [ts]: Opening.ts
local ____lualib = require("lualib_bundle") -- 1
local __TS__New = ____lualib.__TS__New -- 1
local ____exports = {} -- 1
local ____Dora = require("Dora") -- 2
local Color = ____Dora.Color -- 2
local DrawNode = ____Dora.DrawNode -- 2
local Node = ____Dora.Node -- 2
local Vec2 = ____Dora.Vec2 -- 2
local ____Input = require("Script.core.Input") -- 4
local input = ____Input.input -- 4
local ____Audio = require("Script.core.Audio") -- 5
local audio = ____Audio.audio -- 5
local Track = ____Audio.Track -- 5
local ____Viewport = require("Script.core.Viewport") -- 6
local viewport = ____Viewport.viewport -- 6
local ____UI = require("Script.core.UI") -- 7
local drawGlowDot = ____UI.drawGlowDot -- 7
local drawRoundRect = ____UI.drawRoundRect -- 7
local fullScreen = ____UI.fullScreen -- 7
local makeLabel = ____UI.makeLabel -- 7
local Typewriter = ____UI.Typewriter -- 7
local PROLOGUE = "一场认知风暴席卷了精神世界……你的心灵曾在这场风暴里崩塌。但你重生了，来到隔绝风暴的净土——心屿。先疗愈自己，帮助被困的居民，重建心灵。" -- 13
function ____exports.createOpening(opts) -- 25
	local root = Node() -- 26
	local menu = Node() -- 27
	local prologue = Node() -- 28
	local ballDraw = DrawNode() -- 29
	local title -- 31
	local subtitle -- 32
	local btnLabel -- 33
	local btnBg -- 34
	local narrator -- 35
	local skipHint -- 36
	local tw -- 37
	local phase = "menu" -- 38
	local time = 0 -- 39
	local prologueHold = 0 -- 40
	local waitingToProceed = false -- 41
	local proceeded = false -- 42
	local balls = {} -- 43
	local w = viewport.width -- 45
	local h = viewport.height -- 46
	local function buildBalls() -- 48
		local colors = { -- 49
			Color(150, 90, 255, 255), -- 49
			Color(70, 200, 255, 255), -- 49
			Color(255, 120, 210, 255), -- 49
			Color(90, 255, 210, 255) -- 49
		} -- 49
		local corners = { -- 50
			Vec2(-w / 2 + 80, h / 2 - 80), -- 51
			Vec2(w / 2 - 80, h / 2 - 80), -- 52
			Vec2(-w / 2 + 80, -h / 2 + 90), -- 53
			Vec2(w / 2 - 80, -h / 2 + 90) -- 54
		} -- 54
		do -- 54
			local i = 0 -- 56
			while i < 4 do -- 56
				balls[#balls + 1] = { -- 57
					bx = corners[i + 1].x, -- 58
					by = corners[i + 1].y, -- 59
					r = 46 + i * 5, -- 60
					color = colors[i + 1], -- 61
					phase = i * 1.7, -- 62
					speed = 0.5 + i * 0.12, -- 63
					amp = 18 + i * 3 -- 64
				} -- 64
				i = i + 1 -- 56
			end -- 56
		end -- 56
	end -- 48
	local function buildMenu() -- 69
		local bg = DrawNode() -- 70
		fullScreen( -- 71
			bg, -- 71
			Color(12, 10, 28, 255) -- 71
		) -- 71
		bg:addTo(menu) -- 72
		drawGlowDot( -- 75
			bg, -- 75
			Vec2(0, 40), -- 75
			math.min(w, h) * 0.32, -- 75
			Color(90, 70, 180, 90), -- 75
			6 -- 75
		) -- 75
		title = makeLabel( -- 77
			"心屿", -- 77
			84, -- 77
			Color(178, 120, 255, 255) -- 77
		) -- 77
		if title then -- 77
			title.position = Vec2(0, 150) -- 79
			title.anchor = Vec2(0.5, 0.5) -- 80
			title:addTo(menu) -- 81
		end -- 81
		local eng = makeLabel( -- 84
			"Mindful Isle", -- 84
			34, -- 84
			Color(88, 214, 255, 255) -- 84
		) -- 84
		if eng then -- 84
			eng.position = Vec2(0, 88) -- 86
			eng.anchor = Vec2(0.5, 0.5) -- 87
			eng:addTo(menu) -- 88
		end -- 88
		subtitle = makeLabel( -- 91
			"末日重生·治愈向互动作品", -- 91
			24, -- 91
			Color(184, 180, 210, 255) -- 91
		) -- 91
		if subtitle then -- 91
			subtitle.position = Vec2(0, 44) -- 93
			subtitle.anchor = Vec2(0.5, 0.5) -- 94
			subtitle:addTo(menu) -- 95
		end -- 95
		btnBg = DrawNode() -- 98
		drawRoundRect( -- 99
			btnBg, -- 99
			-170, -- 99
			-38, -- 99
			340, -- 99
			76, -- 99
			38, -- 99
			Color(122, 92, 224, 235), -- 99
			2, -- 99
			Color(182, 150, 255, 255) -- 99
		) -- 99
		btnBg.position = Vec2(0, -64) -- 100
		btnBg:addTo(menu) -- 101
		btnLabel = makeLabel( -- 103
			"开始重生之旅", -- 103
			30, -- 103
			Color(255, 255, 255, 255) -- 103
		) -- 103
		if btnLabel then -- 103
			btnLabel.position = Vec2(0, -64) -- 105
			btnLabel.anchor = Vec2(0.5, 0.5) -- 106
			btnLabel:addTo(menu) -- 107
		end -- 107
		local hint = makeLabel( -- 110
			"A 键确认", -- 110
			18, -- 110
			Color(150, 146, 176, 255) -- 110
		) -- 110
		if hint then -- 110
			hint.position = Vec2(0, -110) -- 112
			hint.anchor = Vec2(0.5, 0.5) -- 113
			hint:addTo(menu) -- 114
		end -- 114
		local risk = makeLabel( -- 117
			"本作品仅为情绪觉察工具，不替代临床诊疗", -- 117
			15, -- 117
			Color(112, 108, 138, 255) -- 117
		) -- 117
		if risk then -- 117
			risk.position = Vec2(0, -h / 2 + 24) -- 119
			risk.anchor = Vec2(0.5, 0.5) -- 120
			risk:addTo(menu) -- 121
		end -- 121
	end -- 69
	local function buildPrologue() -- 125
		local dim = DrawNode() -- 126
		fullScreen( -- 127
			dim, -- 127
			Color(6, 5, 14, 235) -- 127
		) -- 127
		dim:addTo(prologue) -- 128
		local box = DrawNode() -- 130
		local boxW = math.min(w * 0.84, 860) -- 131
		local boxH = 320 -- 132
		drawRoundRect( -- 133
			box, -- 133
			-boxW / 2, -- 133
			-boxH / 2, -- 133
			boxW, -- 133
			boxH, -- 133
			26, -- 133
			Color(12, 10, 26, 215), -- 133
			2, -- 133
			Color(120, 102, 220, 170) -- 133
		) -- 133
		box:addTo(prologue) -- 134
		narrator = makeLabel( -- 136
			"", -- 136
			30, -- 136
			Color(238, 235, 255, 255) -- 136
		) -- 136
		if narrator then -- 136
			narrator.textWidth = boxW - 100 -- 138
			narrator.lineGap = 12 -- 139
			narrator.alignment = "Center" -- 140
			narrator.position = Vec2(0, 10) -- 141
			narrator.anchor = Vec2(0.5, 0.5) -- 142
			narrator:addTo(prologue) -- 143
			tw = __TS__New(Typewriter, narrator) -- 144
		end -- 144
		skipHint = makeLabel( -- 147
			"B 键跳过", -- 147
			18, -- 147
			Color(150, 146, 176, 255) -- 147
		) -- 147
		if skipHint then -- 147
			skipHint.position = Vec2(0, -h / 2 + 46) -- 149
			skipHint.anchor = Vec2(0.5, 0.5) -- 150
			skipHint:addTo(prologue) -- 151
		end -- 151
	end -- 125
	local function beginPrologue() -- 155
		phase = "prologue" -- 156
		menu.visible = false -- 157
		prologue.visible = true -- 158
		prologueHold = 0 -- 159
		waitingToProceed = false -- 160
		audio:playBgm(Track.opening, 0.7) -- 161
		if tw then -- 161
			tw:play( -- 162
				PROLOGUE, -- 162
				20, -- 162
				function() -- 162
					waitingToProceed = true -- 162
				end -- 162
			) -- 162
		end -- 162
	end -- 155
	local function proceed() -- 165
		if proceeded then -- 165
			return -- 166
		end -- 166
		proceeded = true -- 167
		opts:onProceed() -- 168
	end -- 165
	local function tick(dt) -- 171
		time = time + dt -- 172
		ballDraw:clear() -- 174
		do -- 174
			local i = 0 -- 175
			while i < #balls do -- 175
				local b = balls[i + 1] -- 176
				local x = b.bx + math.sin(time * b.speed + b.phase) * b.amp -- 177
				local y = b.by + math.cos(time * b.speed * 0.8 + b.phase) * b.amp * 0.7 -- 178
				drawGlowDot( -- 179
					ballDraw, -- 179
					Vec2(x, y), -- 179
					b.r, -- 179
					b.color, -- 179
					4 -- 179
				) -- 179
				i = i + 1 -- 175
			end -- 175
		end -- 175
		if phase == "menu" then -- 175
			if btnBg then -- 175
				local s = 1 + math.sin(time * 3) * 0.03 -- 184
				btnBg.scaleX = s -- 185
				btnBg.scaleY = s -- 186
			end -- 186
			if input:aPressed() then -- 186
				beginPrologue() -- 188
			end -- 188
		else -- 188
			if tw then -- 188
				tw:update(dt) -- 190
			end -- 190
			if waitingToProceed then -- 190
				prologueHold = prologueHold + dt -- 192
				if prologueHold >= 1 then -- 192
					proceed() -- 193
				end -- 193
			elseif input:bPressed() then -- 193
				proceed() -- 195
			end -- 195
		end -- 195
		return false -- 198
	end -- 171
	return { -- 201
		mount = function(self, host) -- 202
			root:addTo(host) -- 203
			menu:addTo(root) -- 204
			prologue:addTo(root) -- 205
			ballDraw:addTo(root) -- 206
		end, -- 202
		start = function(self) -- 208
			buildBalls() -- 209
			buildMenu() -- 210
			buildPrologue() -- 211
			prologue.visible = false -- 212
			root:schedule(function(dt) return tick(dt) end) -- 213
		end, -- 208
		dispose = function(self) -- 215
			root:removeFromParent() -- 216
		end -- 215
	} -- 215
end -- 25
return ____exports -- 25