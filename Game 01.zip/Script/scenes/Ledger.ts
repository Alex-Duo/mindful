// 提示词6：心灵总账本面板（Y 键开/关，右侧滑入，覆盖 60%）
import { Color, DrawNode, Label, Node, Vec2 } from 'Dora';
import { state, StatKey } from 'Script/core/State';
import { DESIGN_WIDTH, DESIGN_HEIGHT } from 'Script/core/Viewport';
import { drawRoundRect, fillRect, makeLabel, setLabelColor } from 'Script/core/UI';

const C_TEXT = Color(236, 233, 255, 255);
const C_DIM = Color(158, 154, 184, 255);
const C_GREEN = Color(96, 222, 140, 255);
const C_RED = Color(236, 106, 108, 255);
const C_PANEL = Color(12, 12, 26, 240);
const C_GLOW = Color(120, 102, 220, 150);

const STAT_LABEL: Record<StatKey, string> = {
  courage: '勇气',
  hope: '希望',
  trust: '信任',
  anxiety: '焦虑',
  selfDoubt: '自我否定',
  guilt: '愧疚',
};

interface Bar {
  key: StatKey;
  kind: 'asset' | 'liability';
  y: number;
  name: Label.Type;
  value: Label.Type;
  display: number;
}

export class LedgerPanel {
  readonly root = Node();
  private panelW: number;
  private pl: number;
  private bg: DrawNode.Type;
  private fills: DrawNode.Type;
  private bars: Bar[] = [];
  private netLabel: Label.Type | undefined;
  private statusLabel: Label.Type | undefined;
  private arrowLabel: Label.Type | undefined;
  private x = 0;
  private targetX = 0;

  constructor() {
    this.panelW = DESIGN_WIDTH * 0.6;
    this.pl = DESIGN_WIDTH / 2 - this.panelW;
    this.x = this.panelW;
    this.targetX = this.panelW;
    this.root.x = this.x;
    this.bg = DrawNode();
    this.fills = DrawNode();
    this.bg.addTo(this.root);
    this.fills.addTo(this.root);
    //this.build();
    //this.root.schedule((dt: number) => {
      //this.update(dt);
      //return false;
    //});
  }

  get isOpen(): boolean {
    return this.targetX < this.panelW * 0.5;
  }

  mount(host: Node.Type): void {
    this.root.addTo(host);
  }

  dispose(): void {
    this.root.removeFromParent();
  }

  open(): void {
    this.targetX = 0;
  }

  close(): void {
    this.targetX = this.panelW;
  }

  toggle(): void {
    if (this.isOpen) this.close();
    else this.open();
  }

  private addLabel(text: string, size: number, color: Color.Type, x: number, y: number, ax: number): Label.Type | undefined {
    const l = makeLabel(text, size, color);
    if (l) {
      l.position = Vec2(x, y);
      l.anchor = Vec2(ax, 0.5);
      l.addTo(this.root);
    }
    return l;
  }

  private addBar(key: StatKey, kind: 'asset' | 'liability', y: number): void {
    const pr = DESIGN_WIDTH / 2;
    const name = this.addLabel(STAT_LABEL[key], 19, C_TEXT, this.pl + 26, y, 0);
    const value = this.addLabel(STAT_LABEL[key] + ' 0/100', 17, C_DIM, pr - 26, y, 1);
    const barW = this.panelW - 52;
    fillRect(this.bg, this.pl + 26, y - 18, barW, 12, Color(32, 30, 54, 255));
    if (name && value) {
      this.bars.push({ key, kind, y: y - 18, name, value, display: state.get(key) });
    }
  }

  private build(): void {
    const halfH = DESIGN_HEIGHT / 2;
    const pr = DESIGN_WIDTH / 2;
    const cx = (this.pl + pr) / 2;
    const top = halfH;

    drawRoundRect(this.bg, this.pl + 8, -halfH + 8, this.panelW - 16, DESIGN_HEIGHT - 16, 22, C_PANEL, 2, C_GLOW);
    fillRect(this.bg, this.pl + 8, -halfH + 24, 5, DESIGN_HEIGHT - 48, C_GLOW);

    this.addLabel('心灵总账本', 32, C_TEXT, cx, top - 40, 0.5);
    this.addLabel('定期盘点·动态平衡', 16, C_DIM, cx, top - 66, 0.5);

    this.addLabel('💎 心灵资产', 22, C_GREEN, this.pl + 26, top - 98, 0);
    const assetKeys: StatKey[] = ['courage', 'hope', 'trust'];
    for (let i = 0; i < 3; i++) this.addBar(assetKeys[i], 'asset', top - 130 - i * 32);

    this.addLabel('🩹 心灵负债', 22, C_RED, this.pl + 26, top - 232, 0);
    const liabKeys: StatKey[] = ['anxiety', 'selfDoubt', 'guilt'];
    for (let i = 0; i < 3; i++) this.addBar(liabKeys[i], 'liability', top - 264 - i * 32);

    this.addLabel('📈 净资产', 22, C_TEXT, this.pl + 26, top - 366, 0);

    this.netLabel = this.addLabel('0', 44, C_GREEN, cx, top - 404, 0.5);
    this.arrowLabel = this.addLabel('↓', 30, C_RED, cx + 70, top - 404, 0.5);
    this.statusLabel = this.addLabel('', 16, C_DIM, cx, top - 436, 0.5);

    this.addLabel('目标不是零负债，而是资产>负债，维持心灵动态平衡', 14, C_DIM, cx, -halfH + 26, 0.5);
  }

  private update(dt: number): void {
    if (this.x !== this.targetX) {
      const speed = this.panelW / 0.28;
      const step = speed * dt;
      const diff = this.targetX - this.x;
      if (Math.abs(diff) <= step) this.x = this.targetX;
      else this.x += diff > 0 ? step : -step;
      this.root.x = this.x;
    }

    for (let i = 0; i < this.bars.length; i++) {
      const b = this.bars[i];
      const target = state.get(b.key);
      b.display += (target - b.display) * Math.min(1, dt * 4);
      if (Math.abs(target - b.display) < 0.5) b.display = target;
      b.value.text = STAT_LABEL[b.key] + ' ' + Math.round(b.display) + '/100';
    }

    this.fills.clear();
    const barW = this.panelW - 52;
    for (let i = 0; i < this.bars.length; i++) {
      const b = this.bars[i];
      const w = Math.max(0, (b.display / 100) * barW);
      const color = b.kind === 'asset' ? C_GREEN : C_RED;
      fillRect(this.fills, this.pl + 26, b.y, w, 12, color);
      fillRect(this.fills, this.pl + 26, b.y + 9, w, 3, Color(255, 255, 255, 42));
    }

    let assets = 0;
    let liab = 0;
    for (let i = 0; i < this.bars.length; i++) {
      if (this.bars[i].kind === 'asset') assets += this.bars[i].display;
      else liab += this.bars[i].display;
    }
    const net = assets - liab;
    const netColor = net >= 0 ? C_GREEN : C_RED;
    if (this.netLabel) {
      this.netLabel.text = '' + Math.round(net);
      setLabelColor(this.netLabel, netColor);
    }
    if (this.arrowLabel) {
      this.arrowLabel.text = net >= 0 ? '↑' : '↓';
      setLabelColor(this.arrowLabel, netColor);
    }
    if (this.statusLabel) {
      this.statusLabel.text = net < 0 ? '⚠️ 资不抵债，心灵需要疗愈' : '✓ 心灵健康运转中';
      setLabelColor(this.statusLabel, netColor);
    }
  }
}
