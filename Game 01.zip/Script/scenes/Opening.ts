// 提示词1：开场界面（标题 / 光球 / 开始按钮 / 风险声明 / 逐字旁白 / B 跳过）
import { Color, DrawNode, Label, Node, TextAlign, Vec2 } from 'Dora';
import { Scene } from 'Script/scenes/SceneManager';
import { input } from 'Script/core/Input';
import { audio, Track } from 'Script/core/Audio';
import { viewport } from 'Script/core/Viewport';
import { drawGlowDot, drawRoundRect, fullScreen, makeLabel, Typewriter } from 'Script/core/UI';

export interface OpeningOptions {
  onProceed: () => void;
}

const PROLOGUE = '一场认知风暴席卷了精神世界……你的心灵曾在这场风暴里崩塌。但你重生了，来到隔绝风暴的净土——心屿。先疗愈自己，帮助被困的居民，重建心灵。';

interface Ball {
  bx: number;
  by: number;
  r: number;
  color: Color.Type;
  phase: number;
  speed: number;
  amp: number;
}

export function createOpening(opts: OpeningOptions): Scene {
  const root = Node();
  const menu = Node();
  const prologue = Node();
  const ballDraw = DrawNode();

  let title: Label.Type | undefined;
  let subtitle: Label.Type | undefined;
  let btnLabel: Label.Type | undefined;
  let btnBg: DrawNode.Type | undefined;
  let narrator: Label.Type | undefined;
  let skipHint: Label.Type | undefined;
  let tw: Typewriter | undefined;
  let phase: 'menu' | 'prologue' = 'menu';
  let time = 0;
  let prologueHold = 0;
  let waitingToProceed = false;
  let proceeded = false;
  const balls: Ball[] = [];

  const w = viewport.width;
  const h = viewport.height;

  function buildBalls(): void {
    const colors: Color.Type[] = [Color(150, 90, 255, 255), Color(70, 200, 255, 255), Color(255, 120, 210, 255), Color(90, 255, 210, 255)];
    const corners: Vec2.Type[] = [
      Vec2(-w / 2 + 80, h / 2 - 80),
      Vec2(w / 2 - 80, h / 2 - 80),
      Vec2(-w / 2 + 80, -h / 2 + 90),
      Vec2(w / 2 - 80, -h / 2 + 90),
    ];
    for (let i = 0; i < 4; i++) {
      balls.push({
        bx: corners[i].x,
        by: corners[i].y,
        r: 46 + i * 5,
        color: colors[i],
        phase: i * 1.7,
        speed: 0.5 + i * 0.12,
        amp: 18 + i * 3,
      });
    }
  }

  function buildMenu(): void {
    const bg = DrawNode();
    fullScreen(bg, Color(12, 10, 28, 255));
    bg.addTo(menu);

    // 中央淡淡的氛围光
    drawGlowDot(bg, Vec2(0, 40), Math.min(w, h) * 0.32, Color(90, 70, 180, 90), 6);

    title = makeLabel('心屿', 84, Color(178, 120, 255, 255));
    if (title) {
      title.position = Vec2(0, 150);
      title.anchor = Vec2(0.5, 0.5);
      title.addTo(menu);
    }

    const eng = makeLabel('Mindful Isle', 34, Color(88, 214, 255, 255));
    if (eng) {
      eng.position = Vec2(0, 88);
      eng.anchor = Vec2(0.5, 0.5);
      eng.addTo(menu);
    }

    subtitle = makeLabel('末日重生·治愈向互动作品', 24, Color(184, 180, 210, 255));
    if (subtitle) {
      subtitle.position = Vec2(0, 44);
      subtitle.anchor = Vec2(0.5, 0.5);
      subtitle.addTo(menu);
    }

    btnBg = DrawNode();
    drawRoundRect(btnBg, -170, -38, 340, 76, 38, Color(122, 92, 224, 235), 2, Color(182, 150, 255, 255));
    btnBg.position = Vec2(0, -64);
    btnBg.addTo(menu);

    btnLabel = makeLabel('开始重生之旅', 30, Color(255, 255, 255, 255));
    if (btnLabel) {
      btnLabel.position = Vec2(0, -64);
      btnLabel.anchor = Vec2(0.5, 0.5);
      btnLabel.addTo(menu);
    }

    const hint = makeLabel('A 键确认', 18, Color(150, 146, 176, 255));
    if (hint) {
      hint.position = Vec2(0, -110);
      hint.anchor = Vec2(0.5, 0.5);
      hint.addTo(menu);
    }

    const risk = makeLabel('本作品仅为情绪觉察工具，不替代临床诊疗', 15, Color(112, 108, 138, 255));
    if (risk) {
      risk.position = Vec2(0, -h / 2 + 24);
      risk.anchor = Vec2(0.5, 0.5);
      risk.addTo(menu);
    }
  }

  function buildPrologue(): void {
    const dim = DrawNode();
    fullScreen(dim, Color(6, 5, 14, 235));
    dim.addTo(prologue);

    const box = DrawNode();
    const boxW = Math.min(w * 0.84, 860);
    const boxH = 320;
    drawRoundRect(box, -boxW / 2, -boxH / 2, boxW, boxH, 26, Color(12, 10, 26, 215), 2, Color(120, 102, 220, 170));
    box.addTo(prologue);

    narrator = makeLabel('', 30, Color(238, 235, 255, 255));
    if (narrator) {
      narrator.textWidth = boxW - 100;
      narrator.lineGap = 12;
      narrator.alignment = TextAlign.Center;
      narrator.position = Vec2(0, 10);
      narrator.anchor = Vec2(0.5, 0.5);
      narrator.addTo(prologue);
      tw = new Typewriter(narrator);
    }

    skipHint = makeLabel('B 键跳过', 18, Color(150, 146, 176, 255));
    if (skipHint) {
      skipHint.position = Vec2(0, -h / 2 + 46);
      skipHint.anchor = Vec2(0.5, 0.5);
      skipHint.addTo(prologue);
    }
  }

  function beginPrologue(): void {
    phase = 'prologue';
    menu.visible = false;
    prologue.visible = true;
    prologueHold = 0;
    waitingToProceed = false;
    audio.playBgm(Track.opening, 0.7);
    if (tw) tw.play(PROLOGUE, 20, () => { waitingToProceed = true; });
  }

  function proceed(): void {
    if (proceeded) return;
    proceeded = true;
    opts.onProceed();
  }

  function tick(dt: number): boolean {
    time += dt;

    ballDraw.clear();
    for (let i = 0; i < balls.length; i++) {
      const b = balls[i];
      const x = b.bx + Math.sin(time * b.speed + b.phase) * b.amp;
      const y = b.by + Math.cos(time * b.speed * 0.8 + b.phase) * b.amp * 0.7;
      drawGlowDot(ballDraw, Vec2(x, y), b.r, b.color, 4);
    }

    if (phase === 'menu') {
      if (btnBg) {
        const s = 1 + Math.sin(time * 3) * 0.03;
        btnBg.scaleX = s;
        btnBg.scaleY = s;
      }
      if (input.aPressed()) beginPrologue();
    } else {
      if (tw) tw.update(dt);
      if (waitingToProceed) {
        prologueHold += dt;
        if (prologueHold >= 1.0) proceed();
      } else if (input.bPressed()) {
        proceed();
      }
    }
    return false;
  }

  return {
    mount(host: Node.Type): void {
      root.addTo(host);
      menu.addTo(root);
      prologue.addTo(root);
      ballDraw.addTo(root);
    },
    start(): void {
      buildBalls();
      buildMenu();
      buildPrologue();
      prologue.visible = false;
      root.schedule((dt: number) => tick(dt));
    },
    dispose(): void {
      root.removeFromParent();
    },
  };
}
