-- [ts]: SceneManager.ts
local ____lualib = require("lualib_bundle") -- 1
local __TS__Class = ____lualib.__TS__Class -- 1
local __TS__New = ____lualib.__TS__New -- 1
local ____exports = {} -- 1
local ____Dora = require("Dora") -- 2
local Node = ____Dora.Node -- 2
local ____UI = require("Script.core.UI") -- 3
local Fader = ____UI.Fader -- 3
____exports.SceneManager = __TS__Class() -- 11
local SceneManager = ____exports.SceneManager -- 11
SceneManager.name = "SceneManager" -- 11
function SceneManager.prototype.____constructor(self, host) -- 17
	self.current = nil -- 15
	self.host = host -- 18
	self.sceneLayer = Node() -- 19
	self.sceneLayer:addTo(host) -- 20
	self.fader = __TS__New(Fader, host) -- 21
	self.fader:setNow(1) -- 22
	self.fader:fadeTo(0, 0.4) -- 23
end -- 17
function SceneManager.prototype.switchTo(self, factory) -- 26
	self.fader:fadeTo( -- 27
		1, -- 27
		0.4, -- 27
		function() -- 27
			if self.current then -- 27
				self.current:dispose() -- 28
			end -- 28
			local next = factory() -- 29
			next:mount(self.sceneLayer) -- 30
			next:start() -- 31
			self.current = next -- 32
			self.fader:fadeTo(0, 0.4) -- 33
		end -- 27
	) -- 27
end -- 26
return ____exports -- 26