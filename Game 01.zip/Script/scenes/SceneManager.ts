// 场景切换 + 全局淡入淡出
import { Node } from 'Dora';
import { Fader } from 'Script/core/UI';

export interface Scene {
  mount(host: Node.Type): void;
  start(): void;
  dispose(): void;
}

export class SceneManager {
  readonly host: Node.Type;
  readonly sceneLayer: Node.Type;
  readonly fader: Fader;
  private current: Scene | undefined = undefined;

  constructor(host: Node.Type) {
    this.host = host;
    this.sceneLayer = Node();
    this.sceneLayer.addTo(host);
    this.fader = new Fader(host); // 在 sceneLayer 之后添加，始终盖在上层
    this.fader.setNow(1);
    this.fader.fadeTo(0, 0.4);
  }

  switchTo(factory: () => Scene): void {
    this.fader.fadeTo(1, 0.4, () => {
      if (this.current) this.current.dispose();
      const next = factory();
      next.mount(this.sceneLayer);
      next.start();
      this.current = next;
      this.fader.fadeTo(0, 0.4);
    });
  }
}
