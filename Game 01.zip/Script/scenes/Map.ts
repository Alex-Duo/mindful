// 提示词2：世界地图（区域节点选择 + 总账本 + 进入暴风湾过渡）
import { Color, DrawNode, Label, Node, TextAlign, Vec2 } from 'Dora';
import { Scene } from 'Script/scenes/SceneManager';
import { input } from 'Script/core/Input';
import { state } from 'Script/core/State';
import { DESIGN_WIDTH } from 'Script/core/Viewport';
import { LedgerPanel } from 'Script/scenes/Ledger';
import { drawGlowDot, FloatText, fullScreen, makeLabel } from 'Script/core/UI';

export interface MapOptions {
  onBack: () => void;
  onEnterStormBay: () => void;
}

interface MapNode {
  id: string;
  label: string;
  desc: string;
  pos: Vec2.Type;
  color: Color.Type;
  name?: Label.Type;
}

export function createMap(opts: MapOptions): Scene {
  const root = Node();
  const bgLayer = Node();
  const nodeLayer = Node();
  const fxLayer = Node();
  const ledger = new LedgerPanel();
  const nodeDraw = DrawNode();

  const nodes: MapNode[] = [];
  let selected = 2; // 默认选中暴风湾
  let transitioning = false;
  let transitionTimer = 0;
  let time = 0;

  function buildIsland(): void {
    const bg = DrawNode();
    fullScreen(bg, Color(14, 20, 34, 255));
    bg.addTo(bgLayer);

    const island = DrawNode();
    island.drawDot(Vec2(0, -10), 216, Color(80, 112, 96, 255));
    island.drawDot(Vec2(0, -10), 205, Color(96, 130, 112, 255));
    island.drawDot(Vec2(0, -10), 74, Color(70, 152, 200, 255));
    island.drawDot(Vec2(0, -10), 58, Color(92, 172, 216, 255));
    // 几条纹理点
    island.drawDot(Vec2(-120, 60), 18, Color(60, 90, 76, 255));
    island.drawDot(Vec2(140, -60), 20, Color(60, 90, 76, 255));
    island.addTo(bgLayer);
  }

  function buildNodes(): void {
    nodes.push({ id: 'mist', label: '🌫️迷雾滩', desc: '反刍思维区·黑雾笼罩', pos: Vec2(-264, 128), color: Color(120, 130, 160, 255) });
    nodes.push({ id: 'forest', label: '🌲枯林', desc: '自我否定区·枯萎荒芜', pos: Vec2(264, 128), color: Color(150, 150, 120, 255) });
    nodes.push({ id: 'stormbay', label: '🌊暴风湾', desc: '灾难化焦虑区·风暴肆虐', pos: Vec2(-264, -148), color: Color(96, 170, 220, 255) });
    nodes.push({ id: 'cave', label: '🕳️回音洞穴', desc: '读心式扭曲区·回音混乱', pos: Vec2(264, -148), color: Color(150, 110, 200, 255) });
    nodes.push({ id: 'lake', label: '🏝️中央湖畔', desc: '安全区', pos: Vec2(0, -10), color: Color(120, 220, 200, 255) });

    for (let i = 0; i < nodes.length; i++) {
      const n = nodes[i];
      const name = makeLabel(n.label, 23, Color(240, 238, 255, 255));
      const desc = makeLabel(n.desc, 16, Color(172, 168, 198, 255));
      if (name) {
        name.position = Vec2(n.pos.x, n.pos.y + 46);
        name.anchor = Vec2(0.5, 0.5);
        name.addTo(nodeLayer);
        n.name = name;
      }
      if (desc) {
        desc.position = Vec2(n.pos.x, n.pos.y + 26);
        desc.anchor = Vec2(0.5, 0.5);
        desc.addTo(nodeLayer);
      }
    }

    const tip = makeLabel('摇杆选择 · A 进入 · Y 总账本', 18, Color(150, 146, 176, 255));
    if (tip) {
      tip.position = Vec2(0, -220);
      tip.anchor = Vec2(0.5, 0.5);
      tip.addTo(nodeLayer);
    }
  }

  function drawNodes(): void {
    nodeDraw.clear();
    for (let i = 0; i < nodes.length; i++) {
      const n = nodes[i];
      const isSel = i === selected;
      const healed = n.id === 'stormbay' && state.stormBayHealed;
      let r = isSel ? 34 : 24;
      let color = n.color;

      if (n.id === 'stormbay' && healed) {
        color = Color(250, 180, 110, 255);
        if (n.name) n.name.text = '🌊暴风湾 已疗愈✅';
      } else if (n.id === 'stormbay') {
        const pulse = 0.62 + 0.38 * Math.sin(time * 4);
        color = Color(Math.round(n.color.r * pulse), Math.round(n.color.g * pulse), Math.round(n.color.b * pulse), 255);
        r = (isSel ? 38 : 30) + Math.sin(time * 4) * 4;
        if (n.name) n.name.text = '🌊暴风湾';
      } else if (isSel) {
        r = 34 + Math.sin(time * 3) * 2;
      }

      drawGlowDot(nodeDraw, n.pos, r, color, 4);
      if (isSel) {
        nodeDraw.drawDot(n.pos, r + 9, Color(color.r, color.g, color.b, 90));
      }
      if (n.name) {
        const s = isSel ? 1.15 : 1;
        n.name.scaleX = s;
        n.name.scaleY = s;
      }
    }
  }

  function selectDir(dx: number, dy: number): void {
    let best = -1;
    let bestScore = -999999;
    for (let i = 0; i < nodes.length; i++) {
      if (i === selected) continue;
      const vx = nodes[i].pos.x - nodes[selected].pos.x;
      const vy = nodes[i].pos.y - nodes[selected].pos.y;
      const len = Math.sqrt(vx * vx + vy * vy);
      if (len < 0.001) continue;
      const dot = (vx * dx + vy * dy) / len;
      if (dot > 0.25) {
        const score = dot - len * 0.0005;
        if (score > bestScore) {
          bestScore = score;
          best = i;
        }
      }
    }
    if (best >= 0) selected = best;
  }

  function beginTransition(): void {
    transitioning = true;
    transitionTimer = 0;
    const dim = DrawNode();
    fullScreen(dim, Color(6, 8, 16, 238));
    dim.addTo(fxLayer);
    const text = makeLabel('你来到了暴风湾。风暴的核心残留地带，风浪不停翻涌，居民习惯预想最坏的结局……', 28, Color(238, 235, 255, 255));
    if (text) {
      text.textWidth = DESIGN_WIDTH * 0.72;
      text.lineGap = 10;
      text.alignment = TextAlign.Center;
      text.position = Vec2(0, 20);
      text.anchor = Vec2(0.5, 0.5);
      text.addTo(fxLayer);
    }
    const hint = makeLabel('A 继续', 18, Color(150, 146, 176, 255));
    if (hint) {
      hint.position = Vec2(0, -180);
      hint.anchor = Vec2(0.5, 0.5);
      hint.addTo(fxLayer);
    }
  }

  function onConfirm(): void {
    const n = nodes[selected];
    if (n.id === 'stormbay') {
      if (state.stormBayHealed) {
        new FloatText(root, '该区域已疗愈，可随时回来做正念冥想', Vec2(0, 60), Color(120, 240, 200, 255), 24);
      } else {
        beginTransition();
      }
    } else if (n.id === 'lake') {
      new FloatText(root, '中央湖畔·安全区', Vec2(0, 60), Color(120, 220, 200, 255), 24);
    } else {
      new FloatText(root, '敬请期待', Vec2(n.pos.x, n.pos.y + 96), Color(220, 210, 160, 255), 24);
    }
  }

  function tick(dt: number): boolean {
    time += dt;
    drawNodes();

    if (transitioning) {
      transitionTimer += dt;
      if ((transitionTimer >= 0.35 && input.aPressed()) || transitionTimer >= 2.8) {
        opts.onEnterStormBay();
      }
      return false;
    }

    if (!ledger.isOpen) {
      if (input.yPressed()) {
        ledger.toggle();
      } else if (input.aPressed()) {
        onConfirm();
      } else if (input.upPressed()) {
        selectDir(0, 1);
      } else if (input.downPressed()) {
        selectDir(0, -1);
      } else if (input.leftPressed()) {
        selectDir(-1, 0);
      } else if (input.rightPressed()) {
        selectDir(1, 0);
      } else if (input.bPressed()) {
        opts.onBack();
      }
    }
    return false;
  }

  return {
    mount(host: Node.Type): void {
      root.addTo(host);
      bgLayer.addTo(root);
      nodeLayer.addTo(root);
      nodeDraw.addTo(nodeLayer);
      fxLayer.addTo(root);
      ledger.mount(root);
    },
    start(): void {
      buildIsland();
      buildNodes();
      root.schedule((dt: number) => tick(dt));
    },
    dispose(): void {
      root.removeFromParent();
    },
  };
}
