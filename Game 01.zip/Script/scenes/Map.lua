-- [ts]: Map.ts
local ____lualib = require("lualib_bundle") -- 1
local __TS__New = ____lualib.__TS__New -- 1
local ____exports = {} -- 1
local ____Dora = require("Dora") -- 2
local Color = ____Dora.Color -- 2
local DrawNode = ____Dora.DrawNode -- 2
local Node = ____Dora.Node -- 2
local Vec2 = ____Dora.Vec2 -- 2
local ____Input = require("Script.core.Input") -- 4
local input = ____Input.input -- 4
local ____State = require("Script.core.State") -- 5
local state = ____State.state -- 5
local ____Viewport = require("Script.core.Viewport") -- 6
local DESIGN_WIDTH = ____Viewport.DESIGN_WIDTH -- 6
local ____Ledger = require("Script.scenes.Ledger") -- 7
local LedgerPanel = ____Ledger.LedgerPanel -- 7
local ____UI = require("Script.core.UI") -- 8
local drawGlowDot = ____UI.drawGlowDot -- 8
local FloatText = ____UI.FloatText -- 8
local fullScreen = ____UI.fullScreen -- 8
local makeLabel = ____UI.makeLabel -- 8
function ____exports.createMap(opts) -- 24
	local root = Node() -- 25
	local bgLayer = Node() -- 26
	local nodeLayer = Node() -- 27
	local fxLayer = Node() -- 28
	local ledger = __TS__New(LedgerPanel) -- 29
	local nodeDraw = DrawNode() -- 30
	local nodes = {} -- 32
	local selected = 2 -- 33
	local transitioning = false -- 34
	local transitionTimer = 0 -- 35
	local time = 0 -- 36
	local function buildIsland() -- 38
		local bg = DrawNode() -- 39
		fullScreen( -- 40
			bg, -- 40
			Color(14, 20, 34, 255) -- 40
		) -- 40
		bg:addTo(bgLayer) -- 41
		local island = DrawNode() -- 43
		island:drawDot( -- 44
			Vec2(0, -10), -- 44
			216, -- 44
			Color(80, 112, 96, 255) -- 44
		) -- 44
		island:drawDot( -- 45
			Vec2(0, -10), -- 45
			205, -- 45
			Color(96, 130, 112, 255) -- 45
		) -- 45
		island:drawDot( -- 46
			Vec2(0, -10), -- 46
			74, -- 46
			Color(70, 152, 200, 255) -- 46
		) -- 46
		island:drawDot( -- 47
			Vec2(0, -10), -- 47
			58, -- 47
			Color(92, 172, 216, 255) -- 47
		) -- 47
		island:drawDot( -- 49
			Vec2(-120, 60), -- 49
			18, -- 49
			Color(60, 90, 76, 255) -- 49
		) -- 49
		island:drawDot( -- 50
			Vec2(140, -60), -- 50
			20, -- 50
			Color(60, 90, 76, 255) -- 50
		) -- 50
		island:addTo(bgLayer) -- 51
	end -- 38
	local function buildNodes() -- 54
		nodes[#nodes + 1] = { -- 55
			id = "mist", -- 55
			label = "🌫️迷雾滩", -- 55
			desc = "反刍思维区·黑雾笼罩", -- 55
			pos = Vec2(-264, 128), -- 55
			color = Color(120, 130, 160, 255) -- 55
		} -- 55
		nodes[#nodes + 1] = { -- 56
			id = "forest", -- 56
			label = "🌲枯林", -- 56
			desc = "自我否定区·枯萎荒芜", -- 56
			pos = Vec2(264, 128), -- 56
			color = Color(150, 150, 120, 255) -- 56
		} -- 56
		nodes[#nodes + 1] = { -- 57
			id = "stormbay", -- 57
			label = "🌊暴风湾", -- 57
			desc = "灾难化焦虑区·风暴肆虐", -- 57
			pos = Vec2(-264, -148), -- 57
			color = Color(96, 170, 220, 255) -- 57
		} -- 57
		nodes[#nodes + 1] = { -- 58
			id = "cave", -- 58
			label = "🕳️回音洞穴", -- 58
			desc = "读心式扭曲区·回音混乱", -- 58
			pos = Vec2(264, -148), -- 58
			color = Color(150, 110, 200, 255) -- 58
		} -- 58
		nodes[#nodes + 1] = { -- 59
			id = "lake", -- 59
			label = "🏝️中央湖畔", -- 59
			desc = "安全区", -- 59
			pos = Vec2(0, -10), -- 59
			color = Color(120, 220, 200, 255) -- 59
		} -- 59
		do -- 59
			local i = 0 -- 61
			while i < #nodes do -- 61
				local n = nodes[i + 1] -- 62
				local name = makeLabel( -- 63
					n.label, -- 63
					23, -- 63
					Color(240, 238, 255, 255) -- 63
				) -- 63
				local desc = makeLabel( -- 64
					n.desc, -- 64
					16, -- 64
					Color(172, 168, 198, 255) -- 64
				) -- 64
				if name then -- 64
					name.position = Vec2(n.pos.x, n.pos.y + 46) -- 66
					name.anchor = Vec2(0.5, 0.5) -- 67
					name:addTo(nodeLayer) -- 68
					n.name = name -- 69
				end -- 69
				if desc then -- 69
					desc.position = Vec2(n.pos.x, n.pos.y + 26) -- 72
					desc.anchor = Vec2(0.5, 0.5) -- 73
					desc:addTo(nodeLayer) -- 74
				end -- 74
				i = i + 1 -- 61
			end -- 61
		end -- 61
		local tip = makeLabel( -- 78
			"摇杆选择 · A 进入 · Y 总账本", -- 78
			18, -- 78
			Color(150, 146, 176, 255) -- 78
		) -- 78
		if tip then -- 78
			tip.position = Vec2(0, -220) -- 80
			tip.anchor = Vec2(0.5, 0.5) -- 81
			tip:addTo(nodeLayer) -- 82
		end -- 82
	end -- 54
	local function drawNodes() -- 86
		nodeDraw:clear() -- 87
		do -- 87
			local i = 0 -- 88
			while i < #nodes do -- 88
				local n = nodes[i + 1] -- 89
				local isSel = i == selected -- 90
				local healed = n.id == "stormbay" and state.stormBayHealed -- 91
				local r = isSel and 34 or 24 -- 92
				local color = n.color -- 93
				if n.id == "stormbay" and healed then -- 93
					color = Color(250, 180, 110, 255) -- 96
					if n.name then -- 96
						n.name.text = "🌊暴风湾 已疗愈✅" -- 97
					end -- 97
				elseif n.id == "stormbay" then -- 97
					local pulse = 0.62 + 0.38 * math.sin(time * 4) -- 99
					color = Color( -- 100
						math.floor(n.color.r * pulse + 0.5), -- 100
						math.floor(n.color.g * pulse + 0.5), -- 100
						math.floor(n.color.b * pulse + 0.5), -- 100
						255 -- 100
					) -- 100
					r = (isSel and 38 or 30) + math.sin(time * 4) * 4 -- 101
					if n.name then -- 101
						n.name.text = "🌊暴风湾" -- 102
					end -- 102
				elseif isSel then -- 102
					r = 34 + math.sin(time * 3) * 2 -- 104
				end -- 104
				drawGlowDot( -- 107
					nodeDraw, -- 107
					n.pos, -- 107
					r, -- 107
					color, -- 107
					4 -- 107
				) -- 107
				if isSel then -- 107
					nodeDraw:drawDot( -- 109
						n.pos, -- 109
						r + 9, -- 109
						Color(color.r, color.g, color.b, 90) -- 109
					) -- 109
				end -- 109
				if n.name then -- 109
					local s = isSel and 1.15 or 1 -- 112
					n.name.scaleX = s -- 113
					n.name.scaleY = s -- 114
				end -- 114
				i = i + 1 -- 88
			end -- 88
		end -- 88
	end -- 86
	local function selectDir(dx, dy) -- 119
		local best = -1 -- 120
		local bestScore = -999999 -- 121
		do -- 121
			local i = 0 -- 122
			while i < #nodes do -- 122
				do -- 122
					if i == selected then -- 122
						goto __continue22 -- 123
					end -- 123
					local vx = nodes[i + 1].pos.x - nodes[selected + 1].pos.x -- 124
					local vy = nodes[i + 1].pos.y - nodes[selected + 1].pos.y -- 125
					local len = math.sqrt(vx * vx + vy * vy) -- 126
					if len < 0.001 then -- 126
						goto __continue22 -- 127
					end -- 127
					local dot = (vx * dx + vy * dy) / len -- 128
					if dot > 0.25 then -- 128
						local score = dot - len * 0.0005 -- 130
						if score > bestScore then -- 130
							bestScore = score -- 132
							best = i -- 133
						end -- 133
					end -- 133
				end -- 133
				::__continue22:: -- 133
				i = i + 1 -- 122
			end -- 122
		end -- 122
		if best >= 0 then -- 122
			selected = best -- 137
		end -- 137
	end -- 119
	local function beginTransition() -- 140
		transitioning = true -- 141
		transitionTimer = 0 -- 142
		local dim = DrawNode() -- 143
		fullScreen( -- 144
			dim, -- 144
			Color(6, 8, 16, 238) -- 144
		) -- 144
		dim:addTo(fxLayer) -- 145
		local text = makeLabel( -- 146
			"你来到了暴风湾。风暴的核心残留地带，风浪不停翻涌，居民习惯预想最坏的结局……", -- 146
			28, -- 146
			Color(238, 235, 255, 255) -- 146
		) -- 146
		if text then -- 146
			text.textWidth = DESIGN_WIDTH * 0.72 -- 148
			text.lineGap = 10 -- 149
			text.alignment = "Center" -- 150
			text.position = Vec2(0, 20) -- 151
			text.anchor = Vec2(0.5, 0.5) -- 152
			text:addTo(fxLayer) -- 153
		end -- 153
		local hint = makeLabel( -- 155
			"A 继续", -- 155
			18, -- 155
			Color(150, 146, 176, 255) -- 155
		) -- 155
		if hint then -- 155
			hint.position = Vec2(0, -180) -- 157
			hint.anchor = Vec2(0.5, 0.5) -- 158
			hint:addTo(fxLayer) -- 159
		end -- 159
	end -- 140
	local function onConfirm() -- 163
		local n = nodes[selected + 1] -- 164
		if n.id == "stormbay" then -- 164
			if state.stormBayHealed then -- 164
				__TS__New( -- 167
					FloatText, -- 167
					root, -- 167
					"该区域已疗愈，可随时回来做正念冥想", -- 167
					Vec2(0, 60), -- 167
					Color(120, 240, 200, 255), -- 167
					24 -- 167
				) -- 167
			else -- 167
				beginTransition() -- 169
			end -- 169
		elseif n.id == "lake" then -- 169
			__TS__New( -- 172
				FloatText, -- 172
				root, -- 172
				"中央湖畔·安全区", -- 172
				Vec2(0, 60), -- 172
				Color(120, 220, 200, 255), -- 172
				24 -- 172
			) -- 172
		else -- 172
			__TS__New( -- 174
				FloatText, -- 174
				root, -- 174
				"敬请期待", -- 174
				Vec2(n.pos.x, n.pos.y + 96), -- 174
				Color(220, 210, 160, 255), -- 174
				24 -- 174
			) -- 174
		end -- 174
	end -- 163
	local function tick(dt) -- 178
		time = time + dt -- 179
		drawNodes() -- 180
		if transitioning then -- 180
			transitionTimer = transitionTimer + dt -- 183
			if transitionTimer >= 0.35 and input:aPressed() or transitionTimer >= 2.8 then -- 183
				opts:onEnterStormBay() -- 185
			end -- 185
			return false -- 187
		end -- 187
		if not ledger.isOpen then -- 187
			if input:yPressed() then -- 187
				ledger:toggle() -- 192
			elseif input:aPressed() then -- 192
				onConfirm() -- 194
			elseif input:upPressed() then -- 194
				selectDir(0, 1) -- 196
			elseif input:downPressed() then -- 196
				selectDir(0, -1) -- 198
			elseif input:leftPressed() then -- 198
				selectDir(-1, 0) -- 200
			elseif input:rightPressed() then -- 200
				selectDir(1, 0) -- 202
			elseif input:bPressed() then -- 202
				opts:onBack() -- 204
			end -- 204
		end -- 204
		return false -- 207
	end -- 178
	return { -- 210
		mount = function(self, host) -- 211
			root:addTo(host) -- 212
			bgLayer:addTo(root) -- 213
			nodeLayer:addTo(root) -- 214
			nodeDraw:addTo(nodeLayer) -- 215
			fxLayer:addTo(root) -- 216
			ledger:mount(root) -- 217
		end, -- 211
		start = function(self) -- 219
			buildIsland() -- 220
			buildNodes() -- 221
			root:schedule(function(dt) return tick(dt) end) -- 222
		end, -- 219
		dispose = function(self) -- 224
			root:removeFromParent() -- 225
		end -- 224
	} -- 224
end -- 24
return ____exports -- 24