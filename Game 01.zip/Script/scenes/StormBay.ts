// 提示词3：暴风湾（占位版本，阶段3实现角色移动与NPC）
import { Color, DrawNode, Node, Vec2 } from 'Dora';
import { Scene } from 'Script/scenes/SceneManager';
import { input } from 'Script/core/Input';
import { fullScreen, makeLabel } from 'Script/core/UI';

export interface StormBayOptions {
  onBack: () => void;
}

export function createStormBay(opts: StormBayOptions): Scene {
  const root = Node();

  function tick(dt: number): boolean {
    if (input.bPressed()) opts.onBack();
    return false;
  }

  return {
    mount(host: Node.Type): void {
      root.addTo(host);
    },
    start(): void {
      const bg = DrawNode();
      fullScreen(bg, Color(26, 34, 48, 255));
      bg.addTo(root);

      const title = makeLabel('暴风湾（占位：阶段3实现角色移动与NPC）', 26, Color(235, 232, 255, 255));
      if (title) {
        title.position = Vec2(0, 0);
        title.anchor = Vec2(0.5, 0.5);
        title.addTo(root);
      }

      const hint = makeLabel('B 返回地图', 18, Color(150, 146, 176, 255));
      if (hint) {
        hint.position = Vec2(0, -60);
        hint.anchor = Vec2(0.5, 0.5);
        hint.addTo(root);
      }

      root.schedule((dt: number) => tick(dt));
    },
    dispose(): void {
      root.removeFromParent();
    },
  };
}
