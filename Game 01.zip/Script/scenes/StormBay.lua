-- [ts]: StormBay.ts
local ____exports = {} -- 1
local ____Dora = require("Dora") -- 2
local Color = ____Dora.Color -- 2
local DrawNode = ____Dora.DrawNode -- 2
local Node = ____Dora.Node -- 2
local Vec2 = ____Dora.Vec2 -- 2
local ____Input = require("Script.core.Input") -- 4
local input = ____Input.input -- 4
local ____UI = require("Script.core.UI") -- 5
local fullScreen = ____UI.fullScreen -- 5
local makeLabel = ____UI.makeLabel -- 5
function ____exports.createStormBay(opts) -- 11
	local root = Node() -- 12
	local function tick(dt) -- 14
		if input:bPressed() then -- 14
			opts:onBack() -- 15
		end -- 15
		return false -- 16
	end -- 14
	return { -- 19
		mount = function(self, host) -- 20
			root:addTo(host) -- 21
		end, -- 20
		start = function(self) -- 23
			local bg = DrawNode() -- 24
			fullScreen( -- 25
				bg, -- 25
				Color(26, 34, 48, 255) -- 25
			) -- 25
			bg:addTo(root) -- 26
			local title = makeLabel( -- 28
				"暴风湾（占位：阶段3实现角色移动与NPC）", -- 28
				26, -- 28
				Color(235, 232, 255, 255) -- 28
			) -- 28
			if title then -- 28
				title.position = Vec2(0, 0) -- 30
				title.anchor = Vec2(0.5, 0.5) -- 31
				title:addTo(root) -- 32
			end -- 32
			local hint = makeLabel( -- 35
				"B 返回地图", -- 35
				18, -- 35
				Color(150, 146, 176, 255) -- 35
			) -- 35
			if hint then -- 35
				hint.position = Vec2(0, -60) -- 37
				hint.anchor = Vec2(0.5, 0.5) -- 38
				hint:addTo(root) -- 39
			end -- 39
			root:schedule(function(dt) return tick(dt) end) -- 42
		end, -- 23
		dispose = function(self) -- 44
			root:removeFromParent() -- 45
		end -- 44
	} -- 44
end -- 11
return ____exports -- 11