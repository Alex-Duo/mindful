// Game 编排：持有场景管理器，提供场景跳转
import { Director } from 'Dora';
import { SceneManager } from 'Script/scenes/SceneManager';
import { createOpening } from 'Script/scenes/Opening';
import { createMap } from 'Script/scenes/Map';
import { createStormBay } from 'Script/scenes/StormBay';

export class Game {
  readonly scenes: SceneManager;

  constructor() {
    this.scenes = new SceneManager(Director.entry);
  }

  start(): void {
    this.gotoOpening();
  }

  gotoOpening(): void {
    this.scenes.switchTo(() => createOpening({ onProceed: () => this.gotoMap() }));
  }

  gotoMap(): void {
    this.scenes.switchTo(() => createMap({
      onBack: () => this.gotoOpening(),
      onEnterStormBay: () => this.gotoStormBay(),
    }));
  }

  gotoStormBay(): void {
    this.scenes.switchTo(() => createStormBay({ onBack: () => this.gotoMap() }));
  }
}

export const game = new Game();
