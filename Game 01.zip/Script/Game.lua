-- [ts]: Game.ts
local ____lualib = require("lualib_bundle") -- 1
local __TS__Class = ____lualib.__TS__Class -- 1
local __TS__New = ____lualib.__TS__New -- 1
local ____exports = {} -- 1
local ____Dora = require("Dora") -- 2
local Director = ____Dora.Director -- 2
local ____SceneManager = require("Script.scenes.SceneManager") -- 3
local SceneManager = ____SceneManager.SceneManager -- 3
local ____Opening = require("Script.scenes.Opening") -- 4
local createOpening = ____Opening.createOpening -- 4
local ____Map = require("Script.scenes.Map") -- 5
local createMap = ____Map.createMap -- 5
local ____StormBay = require("Script.scenes.StormBay") -- 6
local createStormBay = ____StormBay.createStormBay -- 6
____exports.Game = __TS__Class() -- 8
local Game = ____exports.Game -- 8
Game.name = "Game" -- 8
function Game.prototype.____constructor(self) -- 11
	self.scenes = __TS__New(SceneManager, Director.entry) -- 12
end -- 11
function Game.prototype.start(self) -- 15
	self:gotoOpening() -- 16
end -- 15
function Game.prototype.gotoOpening(self) -- 19
	self.scenes:switchTo(function() return createOpening({onProceed = function() return self:gotoMap() end}) end) -- 20
end -- 19
function Game.prototype.gotoMap(self) -- 23
	self.scenes:switchTo(function() return createMap({ -- 24
		onBack = function() return self:gotoOpening() end, -- 25
		onEnterStormBay = function() return self:gotoStormBay() end -- 26
	}) end) -- 26
end -- 23
function Game.prototype.gotoStormBay(self) -- 30
	self.scenes:switchTo(function() return createStormBay({onBack = function() return self:gotoMap() end}) end) -- 31
end -- 30
____exports.game = __TS__New(____exports.Game) -- 35
return ____exports -- 35