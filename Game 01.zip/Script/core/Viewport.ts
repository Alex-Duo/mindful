// 视口适配：以设计分辨率 960x540 为基准，fit 策略缩放相机，保证内容不裁剪。
import { Director, TypeName, View, tolua } from 'Dora';

export const DESIGN_WIDTH = 960;
export const DESIGN_HEIGHT = 540;

export interface ViewportState {
  width: number;
  height: number;
  halfW: number;
  halfH: number;
  zoom: number;
}

export const viewport: ViewportState = {
  width: DESIGN_WIDTH,
  height: DESIGN_HEIGHT,
  halfW: DESIGN_WIDTH / 2,
  halfH: DESIGN_HEIGHT / 2,
  zoom: 1,
};

export function setupViewport(): void {
  const update = () => {
    const camera = tolua.cast(Director.currentCamera, TypeName.Camera2D);
    if (camera) {
      const zoom = Math.min(View.size.height / DESIGN_HEIGHT, View.size.width / DESIGN_WIDTH);
      camera.zoom = zoom;
      viewport.zoom = zoom;
      viewport.width = View.size.width / zoom;
      viewport.height = View.size.height / zoom;
      viewport.halfW = viewport.width / 2;
      viewport.halfH = viewport.height / 2;
    }
  };
  update();
  Director.entry.onAppChange((settingName) => {
    if (settingName === 'Size') update();
  });
}
