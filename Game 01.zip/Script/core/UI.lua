-- [ts]: UI.ts
local ____lualib = require("lualib_bundle") -- 1
local __TS__Class = ____lualib.__TS__Class -- 1
local __TS__StringCharCodeAt = ____lualib.__TS__StringCharCodeAt -- 1
local __TS__StringSubstring = ____lualib.__TS__StringSubstring -- 1
local __TS__SetDescriptor = ____lualib.__TS__SetDescriptor -- 1
local Error = ____lualib.Error -- 1
local RangeError = ____lualib.RangeError -- 1
local ReferenceError = ____lualib.ReferenceError -- 1
local SyntaxError = ____lualib.SyntaxError -- 1
local TypeError = ____lualib.TypeError -- 1
local URIError = ____lualib.URIError -- 1
local __TS__New = ____lualib.__TS__New -- 1
local ____exports = {} -- 1
local ____Dora = require("Dora") -- 2
local Color = ____Dora.Color -- 2
local Color3 = ____Dora.Color3 -- 2
local DrawNode = ____Dora.DrawNode -- 2
local Label = ____Dora.Label -- 2
local Vec2 = ____Dora.Vec2 -- 2
local ____Viewport = require("Script.core.Viewport") -- 3
local viewport = ____Viewport.viewport -- 3
function ____exports.clamp(v, lo, hi) -- 5
	if v < lo then -- 5
		return lo -- 6
	end -- 6
	if v > hi then -- 6
		return hi -- 7
	end -- 7
	return v -- 8
end -- 5
function ____exports.lerp(a, b, t) -- 11
	return a + (b - a) * t -- 12
end -- 11
function ____exports.colorLerp(c1, c2, t) -- 15
	local k = ____exports.clamp(t, 0, 1) -- 16
	return Color( -- 17
		math.floor(____exports.lerp(c1.r, c2.r, k) + 0.5), -- 18
		math.floor(____exports.lerp(c1.g, c2.g, k) + 0.5), -- 19
		math.floor(____exports.lerp(c1.b, c2.b, k) + 0.5), -- 20
		math.floor(____exports.lerp(c1.a, c2.a, k) + 0.5) -- 21
	) -- 21
end -- 15
function ____exports.setLabelColor(label, color) -- 25
	label.color3 = Color3(color.r, color.g, color.b) -- 26
	label.opacity = color.opacity -- 27
end -- 25
function ____exports.makeLabel(text, size, color, font) -- 30
	if font == nil then -- 30
		font = "sarasa-mono-sc-regular" -- 30
	end -- 30
	local l = Label(font, size) -- 31
	if not l then -- 31
		return nil -- 32
	end -- 32
	l.text = text -- 33
	____exports.setLabelColor(l, color) -- 34
	return l -- 35
end -- 30
function ____exports.fillRect(draw, x, y, w, h, color, borderWidth, borderColor) -- 38
	if borderWidth == nil then -- 38
		borderWidth = 0 -- 38
	end -- 38
	draw:drawPolygon( -- 39
		{ -- 40
			Vec2(x, y), -- 40
			Vec2(x + w, y), -- 40
			Vec2(x + w, y + h), -- 40
			Vec2(x, y + h) -- 40
		}, -- 40
		color, -- 41
		borderWidth, -- 42
		borderColor -- 43
	) -- 43
end -- 38
local function arcPoints(cx, cy, r, a0, a1, seg) -- 47
	local pts = {} -- 48
	do -- 48
		local i = 0 -- 49
		while i <= seg do -- 49
			local a = (a0 + (a1 - a0) * i / seg) * math.pi / 180 -- 50
			pts[#pts + 1] = Vec2( -- 51
				cx + r * math.cos(a), -- 51
				cy + r * math.sin(a) -- 51
			) -- 51
			i = i + 1 -- 49
		end -- 49
	end -- 49
	return pts -- 53
end -- 47
local function appendAll(dst, src) -- 56
	do -- 56
		local i = 0 -- 57
		while i < #src do -- 57
			dst[#dst + 1] = src[i + 1] -- 57
			i = i + 1 -- 57
		end -- 57
	end -- 57
end -- 56
function ____exports.drawRoundRect(draw, x, y, w, h, r, color, borderWidth, borderColor) -- 60
	if borderWidth == nil then -- 60
		borderWidth = 0 -- 60
	end -- 60
	local pts = {} -- 61
	local seg = 5 -- 62
	appendAll( -- 63
		pts, -- 63
		arcPoints( -- 63
			x + r, -- 63
			y + r, -- 63
			r, -- 63
			180, -- 63
			270, -- 63
			seg -- 63
		) -- 63
	) -- 63
	appendAll( -- 64
		pts, -- 64
		arcPoints( -- 64
			x + w - r, -- 64
			y + r, -- 64
			r, -- 64
			270, -- 64
			360, -- 64
			seg -- 64
		) -- 64
	) -- 64
	appendAll( -- 65
		pts, -- 65
		arcPoints( -- 65
			x + w - r, -- 65
			y + h - r, -- 65
			r, -- 65
			0, -- 65
			90, -- 65
			seg -- 65
		) -- 65
	) -- 65
	appendAll( -- 66
		pts, -- 66
		arcPoints( -- 66
			x + r, -- 66
			y + h - r, -- 66
			r, -- 66
			90, -- 66
			180, -- 66
			seg -- 66
		) -- 66
	) -- 66
	draw:drawPolygon(pts, color, borderWidth, borderColor) -- 67
end -- 60
function ____exports.fullScreen(draw, color) -- 70
	____exports.fillRect( -- 71
		draw, -- 71
		-viewport.halfW, -- 71
		-viewport.halfH, -- 71
		viewport.width, -- 71
		viewport.height, -- 71
		color -- 71
	) -- 71
end -- 70
function ____exports.drawGlowDot(draw, pos, radius, color, layers) -- 75
	if layers == nil then -- 75
		layers = 3 -- 75
	end -- 75
	do -- 75
		local i = layers -- 76
		while i >= 1 do -- 76
			local k = i / layers -- 77
			local r = radius * (1.7 - k * 0.7) -- 78
			local a = math.floor(color.a * k * 0.26 + 0.5) -- 79
			draw:drawDot( -- 80
				pos, -- 80
				r, -- 80
				Color(color.r, color.g, color.b, a) -- 80
			) -- 80
			i = i - 1 -- 76
		end -- 76
	end -- 76
	draw:drawDot(pos, radius, color) -- 82
end -- 75
____exports.Fader = __TS__Class() -- 86
local Fader = ____exports.Fader -- 86
Fader.name = "Fader" -- 86
function Fader.prototype.____constructor(self, host) -- 93
	self.opacity = 1 -- 88
	self.target = 1 -- 89
	self.speed = 0 -- 90
	self.done = nil -- 91
	self.node = DrawNode() -- 94
	self:redraw() -- 95
	self.node:addTo(host) -- 96
	self.node:schedule(function(dt) -- 97
		self:update(dt) -- 98
		return false -- 99
	end) -- 97
end -- 93
function Fader.prototype.redraw(self) -- 103
	local w = viewport.width -- 104
	local h = viewport.height -- 105
	local m = 40 -- 106
	self.node:clear() -- 107
	self.node:drawPolygon( -- 108
		{ -- 109
			Vec2(-w / 2 - m, -h / 2 - m), -- 109
			Vec2(w / 2 + m, -h / 2 - m), -- 109
			Vec2(w / 2 + m, h / 2 + m), -- 109
			Vec2(-w / 2 - m, h / 2 + m) -- 109
		}, -- 109
		Color(8, 6, 12, 255) -- 110
	) -- 110
end -- 103
function Fader.prototype.fadeTo(self, target, duration, done) -- 114
	self.target = target -- 115
	self.speed = duration > 0 and math.abs(target - self.opacity) / duration or 1 -- 116
	self.done = done -- 117
end -- 114
function Fader.prototype.setNow(self, opacity) -- 120
	self.opacity = opacity -- 121
	self.target = opacity -- 122
	self.node.opacity = opacity -- 123
	self.node.visible = opacity > 0.001 -- 124
end -- 120
function Fader.prototype.update(self, dt) -- 127
	if self.opacity == self.target then -- 127
		return -- 128
	end -- 128
	local step = self.speed * dt -- 129
	local diff = self.target - self.opacity -- 130
	if math.abs(diff) <= step then -- 130
		self.opacity = self.target -- 132
		self.node.opacity = self.opacity -- 133
		self.node.visible = self.opacity > 0.001 -- 134
		local d = self.done -- 135
		self.done = nil -- 136
		if d then -- 136
			d() -- 137
		end -- 137
	else -- 137
		self.opacity = self.opacity + (diff > 0 and step or -step) -- 139
		self.node.opacity = self.opacity -- 140
	end -- 140
end -- 127
function ____exports.utf8Chars(s) -- 146
	local out = {} -- 147
	local n = #s -- 148
	local i = 0 -- 149
	while i < n do -- 149
		local b = __TS__StringCharCodeAt(s, i) -- 151
		local len = 1 -- 152
		if b >= 240 then -- 152
			len = 4 -- 153
		elseif b >= 224 then -- 153
			len = 3 -- 154
		elseif b >= 192 then -- 154
			len = 2 -- 155
		end -- 155
		out[#out + 1] = __TS__StringSubstring(s, i, i + len) -- 156
		i = i + len -- 157
	end -- 157
	return out -- 159
end -- 146
____exports.Typewriter = __TS__Class() -- 163
local Typewriter = ____exports.Typewriter -- 163
Typewriter.name = "Typewriter" -- 163
function Typewriter.prototype.____constructor(self, label) -- 174
	self.full = "" -- 165
	self.chars = {} -- 166
	self.current = "" -- 167
	self.shown = 0 -- 168
	self.timer = 0 -- 169
	self.interval = 0.05 -- 170
	self.active = false -- 171
	self.done = nil -- 172
	self.label = label -- 175
end -- 174
function Typewriter.prototype.play(self, text, cps, done) -- 178
	if cps == nil then -- 178
		cps = 20 -- 178
	end -- 178
	self.full = text -- 179
	self.chars = ____exports.utf8Chars(text) -- 180
	self.current = "" -- 181
	self.shown = 0 -- 182
	self.timer = 0 -- 183
	self.interval = cps > 0 and 1 / cps or 0.02 -- 184
	self.active = true -- 185
	self.done = done -- 186
	self.label.text = "" -- 187
end -- 178
function Typewriter.prototype.skip(self) -- 194
	if not self.active then -- 194
		return -- 195
	end -- 195
	self.label.text = self.full -- 196
	self.active = false -- 197
	local d = self.done -- 198
	self.done = nil -- 199
	if d then -- 199
		d() -- 200
	end -- 200
end -- 194
function Typewriter.prototype.update(self, dt) -- 203
	if not self.active then -- 203
		return -- 204
	end -- 204
	self.timer = self.timer + dt -- 205
	while self.timer >= self.interval and self.shown < #self.chars do -- 205
		self.current = self.current .. self.chars[self.shown + 1] -- 207
		self.shown = self.shown + 1 -- 208
		self.timer = self.timer - self.interval -- 209
	end -- 209
	self.label.text = self.current -- 211
	if self.shown >= #self.chars then -- 211
		self.active = false -- 213
		local d = self.done -- 214
		self.done = nil -- 215
		if d then -- 215
			d() -- 216
		end -- 216
	end -- 216
end -- 203
__TS__SetDescriptor( -- 203
	Typewriter.prototype, -- 203
	"finished", -- 203
	{get = function(self) -- 203
		return not self.active -- 191
	end}, -- 191
	true -- 191
) -- 191
____exports.FloatText = __TS__Class() -- 222
local FloatText = ____exports.FloatText -- 222
FloatText.name = "FloatText" -- 222
function FloatText.prototype.____constructor(self, host, text, pos, color, size) -- 228
	if size == nil then -- 228
		size = 26 -- 228
	end -- 228
	self.vy = 60 -- 224
	self.life = 1.15 -- 225
	self.t = 0 -- 226
	local l = ____exports.makeLabel(text, size, color) -- 229
	if not l then -- 229
		error( -- 230
			__TS__New(Error, "FloatText: failed to create label"), -- 230
			0 -- 230
		) -- 230
	end -- 230
	self.node = l -- 231
	self.node.position = pos -- 232
	self.node.anchor = Vec2(0.5, 0.5) -- 233
	self.node:addTo(host) -- 234
	self.node:schedule(function(dt) -- 235
		self.t = self.t + dt -- 236
		local ____self_node_0, ____y_1 = self.node, "y" -- 236
		____self_node_0[____y_1] = ____self_node_0[____y_1] + self.vy * dt -- 237
		local a = 1 - self.t / self.life -- 238
		self.node.opacity = a < 0 and 0 or a -- 239
		if self.t >= self.life then -- 239
			self.node:removeFromParent() -- 241
			return true -- 242
		end -- 242
		return false -- 244
	end) -- 235
end -- 228
return ____exports -- 228