// 心灵总账本：全局共享的游戏状态（6 项数值 + 任务/崩溃/疗愈标记）
export type StatKey = 'courage' | 'hope' | 'trust' | 'anxiety' | 'selfDoubt' | 'guilt';
export type NpcId = 'xiaofeng' | 'alang' | 'xiaoyu' | 'leishu';

export interface StatDelta {
  courage?: number;
  hope?: number;
  trust?: number;
  anxiety?: number;
  selfDoubt?: number;
  guilt?: number;
}

export interface StatMeta {
  key: StatKey;
  label: string;
  kind: 'asset' | 'liability';
}

export const STATS: StatMeta[] = [
  { key: 'courage', label: '勇气', kind: 'asset' },
  { key: 'hope', label: '希望', kind: 'asset' },
  { key: 'trust', label: '信任', kind: 'asset' },
  { key: 'anxiety', label: '焦虑', kind: 'liability' },
  { key: 'selfDoubt', label: '自我否定', kind: 'liability' },
  { key: 'guilt', label: '愧疚', kind: 'liability' },
];

export const ASSET_STATS: StatMeta[] = [STATS[0], STATS[1], STATS[2]];
export const LIABILITY_STATS: StatMeta[] = [STATS[3], STATS[4], STATS[5]];

export const NPC_IDS: NpcId[] = ['xiaofeng', 'alang', 'xiaoyu', 'leishu'];

function clamp(v: number, lo: number, hi: number): number {
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

export class GameState {
  values = {
    courage: 30,
    hope: 15,
    trust: 20,
    anxiety: 80,
    selfDoubt: 40,
    guilt: 30,
  };

  npcDone: Record<NpcId, boolean> = { xiaofeng: false, alang: false, xiaoyu: false, leishu: false };
  wrongChoices = 0;
  breakdownTriggered = false;
  breakdownRecovered = false;
  stormBayHealed = false;
  meditationDone = false;
  introSeen = false;

  get(key: StatKey): number {
    return this.values[key];
  }

  set(key: StatKey, value: number): void {
    this.values[key] = clamp(Math.round(value), 0, 100);
  }

  apply(delta: StatDelta): void {
    for (let i = 0; i < STATS.length; i++) {
      const meta = STATS[i];
      const d = delta[meta.key];
      if (d !== undefined) this.set(meta.key, this.get(meta.key) + d);
    }
  }

  get assets(): number {
    return this.values.courage + this.values.hope + this.values.trust;
  }

  get liabilities(): number {
    return this.values.anxiety + this.values.selfDoubt + this.values.guilt;
  }

  get net(): number {
    return this.assets - this.liabilities;
  }

  get npcCompletedCount(): number {
    let n = 0;
    for (let i = 0; i < NPC_IDS.length; i++) {
      if (this.npcDone[NPC_IDS[i]]) n++;
    }
    return n;
  }

  get allNpcDone(): boolean {
    return this.npcCompletedCount >= NPC_IDS.length;
  }
}

export const state = new GameState();
