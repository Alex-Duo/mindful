-- [ts]: Audio.ts
local ____lualib = require("lualib_bundle") -- 1
local __TS__Class = ____lualib.__TS__Class -- 1
local __TS__New = ____lualib.__TS__New -- 1
local ____exports = {} -- 1
local ____Dora = require("Dora") -- 2
local Audio = ____Dora.Audio -- 2
____exports.Track = { -- 4
	opening = "Audio/bgm_opening.ogg", -- 5
	stormBay = "Audio/bgm_stormbay.ogg", -- 6
	meditation = "Audio/bgm_meditation.ogg", -- 7
	breakdown = "Audio/bgm_breakdown.ogg", -- 8
	sfxConfirm = "Audio/sfx_confirm.wav", -- 9
	sfxHeal = "Audio/sfx_heal.wav", -- 10
	sfxBreath = "Audio/sfx_breath.wav" -- 11
} -- 11
____exports.AudioManager = __TS__Class() -- 14
local AudioManager = ____exports.AudioManager -- 14
AudioManager.name = "AudioManager" -- 14
function AudioManager.prototype.____constructor(self) -- 14
	self.enabled = false -- 15
	self.currentBgm = "" -- 16
end -- 14
function AudioManager.prototype.playBgm(self, track, volume, crossFade) -- 18
	if volume == nil then -- 18
		volume = 1 -- 18
	end -- 18
	if crossFade == nil then -- 18
		crossFade = 0.8 -- 18
	end -- 18
	if not self.enabled then -- 18
		return -- 19
	end -- 19
	if self.currentBgm == track then -- 19
		Audio.globalVolume = volume -- 21
		return -- 22
	end -- 22
	self.currentBgm = track -- 24
	Audio.globalVolume = volume -- 25
	Audio:playStream(track, true, crossFade) -- 26
end -- 18
function AudioManager.prototype.stopBgm(self, fade) -- 29
	if fade == nil then -- 29
		fade = 1 -- 29
	end -- 29
	if not self.enabled then -- 29
		return -- 30
	end -- 30
	self.currentBgm = "" -- 31
	Audio:stopStream(fade) -- 32
end -- 29
function AudioManager.prototype.playSfx(self, track) -- 35
	if not self.enabled then -- 35
		return -- 36
	end -- 36
	Audio:play(track, false) -- 37
end -- 35
function AudioManager.prototype.playMeditationBgm(self) -- 41
	self:playBgm(____exports.Track.meditation, 0.7) -- 42
end -- 41
function AudioManager.prototype.playStormBayBgm(self) -- 45
	self:playBgm(____exports.Track.stormBay, 1) -- 46
end -- 45
____exports.audio = __TS__New(____exports.AudioManager) -- 50
return ____exports -- 50