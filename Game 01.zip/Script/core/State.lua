-- [ts]: State.ts
local ____lualib = require("lualib_bundle") -- 1
local __TS__Class = ____lualib.__TS__Class -- 1
local __TS__SetDescriptor = ____lualib.__TS__SetDescriptor -- 1
local __TS__New = ____lualib.__TS__New -- 1
local ____exports = {} -- 1
____exports.STATS = { -- 20
	{key = "courage", label = "勇气", kind = "asset"}, -- 21
	{key = "hope", label = "希望", kind = "asset"}, -- 22
	{key = "trust", label = "信任", kind = "asset"}, -- 23
	{key = "anxiety", label = "焦虑", kind = "liability"}, -- 24
	{key = "selfDoubt", label = "自我否定", kind = "liability"}, -- 25
	{key = "guilt", label = "愧疚", kind = "liability"} -- 26
} -- 26
____exports.ASSET_STATS = {____exports.STATS[1], ____exports.STATS[2], ____exports.STATS[3]} -- 29
____exports.LIABILITY_STATS = {____exports.STATS[4], ____exports.STATS[5], ____exports.STATS[6]} -- 30
____exports.NPC_IDS = {"xiaofeng", "alang", "xiaoyu", "leishu"} -- 32
local function clamp(v, lo, hi) -- 34
	if v < lo then -- 34
		return lo -- 35
	end -- 35
	if v > hi then -- 35
		return hi -- 36
	end -- 36
	return v -- 37
end -- 34
____exports.GameState = __TS__Class() -- 40
local GameState = ____exports.GameState -- 40
GameState.name = "GameState" -- 40
function GameState.prototype.____constructor(self) -- 40
	self.values = { -- 41
		courage = 30, -- 42
		hope = 15, -- 43
		trust = 20, -- 44
		anxiety = 80, -- 45
		selfDoubt = 40, -- 46
		guilt = 30 -- 47
	} -- 47
	self.npcDone = {xiaofeng = false, alang = false, xiaoyu = false, leishu = false} -- 50
	self.wrongChoices = 0 -- 51
	self.breakdownTriggered = false -- 52
	self.breakdownRecovered = false -- 53
	self.stormBayHealed = false -- 54
	self.meditationDone = false -- 55
	self.introSeen = false -- 56
end -- 40
function GameState.prototype.get(self, key) -- 58
	return self.values[key] -- 59
end -- 58
function GameState.prototype.set(self, key, value) -- 62
	self.values[key] = clamp( -- 63
		math.floor(value + 0.5), -- 63
		0, -- 63
		100 -- 63
	) -- 63
end -- 62
function GameState.prototype.apply(self, delta) -- 66
	do -- 66
		local i = 0 -- 67
		while i < #____exports.STATS do -- 67
			local meta = ____exports.STATS[i + 1] -- 68
			local d = delta[meta.key] -- 69
			if d ~= nil then -- 69
				self:set( -- 70
					meta.key, -- 70
					self:get(meta.key) + d -- 70
				) -- 70
			end -- 70
			i = i + 1 -- 67
		end -- 67
	end -- 67
end -- 66
__TS__SetDescriptor( -- 66
	GameState.prototype, -- 66
	"assets", -- 66
	{get = function(self) -- 66
		return self.values.courage + self.values.hope + self.values.trust -- 75
	end}, -- 75
	true -- 75
) -- 75
__TS__SetDescriptor( -- 75
	GameState.prototype, -- 75
	"liabilities", -- 75
	{get = function(self) -- 75
		return self.values.anxiety + self.values.selfDoubt + self.values.guilt -- 79
	end}, -- 79
	true -- 79
) -- 79
__TS__SetDescriptor( -- 79
	GameState.prototype, -- 79
	"net", -- 79
	{get = function(self) -- 79
		return self.assets - self.liabilities -- 83
	end}, -- 83
	true -- 83
) -- 83
__TS__SetDescriptor( -- 83
	GameState.prototype, -- 83
	"npcCompletedCount", -- 83
	{get = function(self) -- 83
		local n = 0 -- 87
		do -- 87
			local i = 0 -- 88
			while i < #____exports.NPC_IDS do -- 88
				if self.npcDone[____exports.NPC_IDS[i + 1]] then -- 88
					n = n + 1 -- 89
				end -- 89
				i = i + 1 -- 88
			end -- 88
		end -- 88
		return n -- 91
	end}, -- 91
	true -- 91
) -- 91
__TS__SetDescriptor( -- 91
	GameState.prototype, -- 91
	"allNpcDone", -- 91
	{get = function(self) -- 91
		return self.npcCompletedCount >= #____exports.NPC_IDS -- 95
	end}, -- 95
	true -- 95
) -- 95
____exports.state = __TS__New(____exports.GameState) -- 99
return ____exports -- 99