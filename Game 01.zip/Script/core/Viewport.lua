-- [ts]: Viewport.ts
local ____exports = {} -- 1
local ____Dora = require("Dora") -- 2
local Director = ____Dora.Director -- 2
local View = ____Dora.View -- 2
local tolua = ____Dora.tolua -- 2
____exports.DESIGN_WIDTH = 960 -- 4
____exports.DESIGN_HEIGHT = 540 -- 5
____exports.viewport = { -- 15
	width = ____exports.DESIGN_WIDTH, -- 16
	height = ____exports.DESIGN_HEIGHT, -- 17
	halfW = ____exports.DESIGN_WIDTH / 2, -- 18
	halfH = ____exports.DESIGN_HEIGHT / 2, -- 19
	zoom = 1 -- 20
} -- 20
function ____exports.setupViewport() -- 23
	local function update() -- 24
		local camera = tolua.cast(Director.currentCamera, "Camera2D") -- 25
		if camera then -- 25
			local zoom = math.min(View.size.height / ____exports.DESIGN_HEIGHT, View.size.width / ____exports.DESIGN_WIDTH) -- 27
			camera.zoom = zoom -- 28
			____exports.viewport.zoom = zoom -- 29
			____exports.viewport.width = View.size.width / zoom -- 30
			____exports.viewport.height = View.size.height / zoom -- 31
			____exports.viewport.halfW = ____exports.viewport.width / 2 -- 32
			____exports.viewport.halfH = ____exports.viewport.height / 2 -- 33
		end -- 33
	end -- 24
	update() -- 36
	Director.entry:onAppChange(function(settingName) -- 37
		if settingName == "Size" then -- 37
			update() -- 38
		end -- 38
	end) -- 37
end -- 23
return ____exports -- 23