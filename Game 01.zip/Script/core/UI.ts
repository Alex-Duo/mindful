// 通用 UI 助手：颜色/几何/淡入淡出/打字机/飘字
import { Color, Color3, DrawNode, Label, Node, Vec2 } from 'Dora';
import { viewport } from 'Script/core/Viewport';

export function clamp(v: number, lo: number, hi: number): number {
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

export function colorLerp(c1: Color.Type, c2: Color.Type, t: number): Color.Type {
  const k = clamp(t, 0, 1);
  return Color(
    Math.round(lerp(c1.r, c2.r, k)),
    Math.round(lerp(c1.g, c2.g, k)),
    Math.round(lerp(c1.b, c2.b, k)),
    Math.round(lerp(c1.a, c2.a, k)),
  );
}

export function setLabelColor(label: Label.Type, color: Color.Type): void {
  label.color3 = Color3(color.r, color.g, color.b);
  label.opacity = color.opacity;
}

export function makeLabel(text: string, size: number, color: Color.Type, font = 'sarasa-mono-sc-regular'): Label.Type | undefined {
  const l = Label(font, size);
  if (!l) return undefined;
  l.text = text;
  setLabelColor(l, color);
  return l;
}

export function fillRect(draw: DrawNode.Type, x: number, y: number, w: number, h: number, color: Color.Type, borderWidth = 0, borderColor?: Color.Type): void {
  draw.drawPolygon(
    [Vec2(x, y), Vec2(x + w, y), Vec2(x + w, y + h), Vec2(x, y + h)],
    color,
    borderWidth,
    borderColor,
  );
}

function arcPoints(cx: number, cy: number, r: number, a0: number, a1: number, seg: number): Vec2.Type[] {
  const pts: Vec2.Type[] = [];
  for (let i = 0; i <= seg; i++) {
    const a = (a0 + (a1 - a0) * i / seg) * Math.PI / 180;
    pts.push(Vec2(cx + r * Math.cos(a), cy + r * Math.sin(a)));
  }
  return pts;
}

function appendAll(dst: Vec2.Type[], src: Vec2.Type[]): void {
  for (let i = 0; i < src.length; i++) dst.push(src[i]);
}

export function drawRoundRect(draw: DrawNode.Type, x: number, y: number, w: number, h: number, r: number, color: Color.Type, borderWidth = 0, borderColor?: Color.Type): void {
  const pts: Vec2.Type[] = [];
  const seg = 5;
  appendAll(pts, arcPoints(x + r, y + r, r, 180, 270, seg));
  appendAll(pts, arcPoints(x + w - r, y + r, r, 270, 360, seg));
  appendAll(pts, arcPoints(x + w - r, y + h - r, r, 0, 90, seg));
  appendAll(pts, arcPoints(x + r, y + h - r, r, 90, 180, seg));
  draw.drawPolygon(pts, color, borderWidth, borderColor);
}

export function fullScreen(draw: DrawNode.Type, color: Color.Type): void {
  fillRect(draw, -viewport.halfW, -viewport.halfH, viewport.width, viewport.height, color);
}

// 用多层同心圆模拟柔和发光
export function drawGlowDot(draw: DrawNode.Type, pos: Vec2.Type, radius: number, color: Color.Type, layers = 3): void {
  for (let i = layers; i >= 1; i--) {
    const k = i / layers;
    const r = radius * (1.7 - k * 0.7);
    const a = Math.round(color.a * k * 0.26);
    draw.drawDot(pos, r, Color(color.r, color.g, color.b, a));
  }
  draw.drawDot(pos, radius, color);
}

// 全屏黑色淡入淡出遮罩
export class Fader {
  readonly node: DrawNode.Type;
  opacity = 1;
  private target = 1;
  private speed = 0;
  private done: (() => void) | undefined = undefined;

  constructor(host: Node.Type) {
    this.node = DrawNode();
    this.redraw();
    this.node.addTo(host);
    this.node.schedule((dt: number) => {
      this.update(dt);
      return false;
    });
  }

  private redraw(): void {
    const w = viewport.width;
    const h = viewport.height;
    const m = 40;
    this.node.clear();
    this.node.drawPolygon(
      [Vec2(-w / 2 - m, -h / 2 - m), Vec2(w / 2 + m, -h / 2 - m), Vec2(w / 2 + m, h / 2 + m), Vec2(-w / 2 - m, h / 2 + m)],
      Color(8, 6, 12, 255),
    );
  }

  fadeTo(target: number, duration: number, done?: () => void): void {
    this.target = target;
    this.speed = duration > 0 ? Math.abs(target - this.opacity) / duration : 1;
    this.done = done;
  }

  setNow(opacity: number): void {
    this.opacity = opacity;
    this.target = opacity;
    this.node.opacity = opacity;
    this.node.visible = opacity > 0.001;
  }

  private update(dt: number): void {
    if (this.opacity === this.target) return;
    const step = this.speed * dt;
    const diff = this.target - this.opacity;
    if (Math.abs(diff) <= step) {
      this.opacity = this.target;
      this.node.opacity = this.opacity;
      this.node.visible = this.opacity > 0.001;
      const d = this.done;
      this.done = undefined;
      if (d) d();
    } else {
      this.opacity += diff > 0 ? step : -step;
      this.node.opacity = this.opacity;
    }
  }
}

// 将 UTF-8 字符串按码点拆成字符数组。Dora 的 charCodeAt/substring 均为字节语义。
export function utf8Chars(s: string): string[] {
  const out: string[] = [];
  const n = s.length; // 字节长度
  let i = 0;
  while (i < n) {
    const b = s.charCodeAt(i);
    let len = 1;
    if (b >= 0xF0) len = 4;
    else if (b >= 0xE0) len = 3;
    else if (b >= 0xC0) len = 2;
    out.push(s.substring(i, i + len));
    i += len;
  }
  return out;
}

// 逐字打字机（UTF-8 码点安全）
export class Typewriter {
  private label: Label.Type;
  private full = '';
  private chars: string[] = [];
  private current = '';
  private shown = 0;
  private timer = 0;
  private interval = 0.05;
  private active = false;
  private done: (() => void) | undefined = undefined;

  constructor(label: Label.Type) {
    this.label = label;
  }

  play(text: string, cps = 20, done?: () => void): void {
    this.full = text;
    this.chars = utf8Chars(text);
    this.current = '';
    this.shown = 0;
    this.timer = 0;
    this.interval = cps > 0 ? 1 / cps : 0.02;
    this.active = true;
    this.done = done;
    this.label.text = '';
  }

  get finished(): boolean {
    return !this.active;
  }

  skip(): void {
    if (!this.active) return;
    this.label.text = this.full;
    this.active = false;
    const d = this.done;
    this.done = undefined;
    if (d) d();
  }

  update(dt: number): void {
    if (!this.active) return;
    this.timer += dt;
    while (this.timer >= this.interval && this.shown < this.chars.length) {
      this.current += this.chars[this.shown];
      this.shown++;
      this.timer -= this.interval;
    }
    this.label.text = this.current;
    if (this.shown >= this.chars.length) {
      this.active = false;
      const d = this.done;
      this.done = undefined;
      if (d) d();
    }
  }
}

// 上升并淡出的飘字（数值变化反馈）
export class FloatText {
  readonly node: Label.Type;
  private vy = 60;
  private life = 1.15;
  private t = 0;

  constructor(host: Node.Type, text: string, pos: Vec2.Type, color: Color.Type, size = 26) {
    const l = makeLabel(text, size, color);
    if (!l) throw new Error('FloatText: failed to create label');
    this.node = l;
    this.node.position = pos;
    this.node.anchor = Vec2(0.5, 0.5);
    this.node.addTo(host);
    this.node.schedule((dt: number) => {
      this.t += dt;
      this.node.y += this.vy * dt;
      const a = 1 - this.t / this.life;
      this.node.opacity = a < 0 ? 0 : a;
      if (this.t >= this.life) {
        this.node.removeFromParent();
        return true;
      }
      return false;
    });
  }
}
