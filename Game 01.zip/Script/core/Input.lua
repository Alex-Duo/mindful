-- [ts]: Input.ts
local ____lualib = require("lualib_bundle") -- 1
local __TS__Class = ____lualib.__TS__Class -- 1
local __TS__New = ____lualib.__TS__New -- 1
local ____exports = {} -- 1
local ____Dora = require("Dora") -- 2
local Controller = ____Dora.Controller -- 2
local Keyboard = ____Dora.Keyboard -- 2
local function clamp(v, lo, hi) -- 4
	if v < lo then -- 4
		return lo -- 5
	end -- 5
	if v > hi then -- 5
		return hi -- 6
	end -- 6
	return v -- 7
end -- 4
local function anyDown(keys) -- 10
	do -- 10
		local i = 0 -- 11
		while i < #keys do -- 11
			if Keyboard:isKeyDown(keys[i + 1]) then -- 11
				return true -- 12
			end -- 12
			i = i + 1 -- 11
		end -- 11
	end -- 11
	return false -- 14
end -- 10
local function anyHeld(keys) -- 17
	do -- 17
		local i = 0 -- 18
		while i < #keys do -- 18
			if Keyboard:isKeyPressed(keys[i + 1]) then -- 18
				return true -- 19
			end -- 19
			i = i + 1 -- 18
		end -- 18
	end -- 18
	return false -- 21
end -- 17
local A_KEYS = {"Return", "Z", "Space"} -- 24
local B_KEYS = {"Escape", "BackSpace"} -- 25
____exports.InputManager = __TS__Class() -- 27
local InputManager = ____exports.InputManager -- 27
InputManager.name = "InputManager" -- 27
function InputManager.prototype.____constructor(self) -- 27
	self.cid = 0 -- 28
end -- 27
function InputManager.prototype.aPressed(self) -- 30
	return Controller:isButtonDown(self.cid, "a") or anyDown(A_KEYS) -- 31
end -- 30
function InputManager.prototype.bPressed(self) -- 34
	return Controller:isButtonDown(self.cid, "b") or anyDown(B_KEYS) -- 35
end -- 34
function InputManager.prototype.xPressed(self) -- 38
	return Controller:isButtonDown(self.cid, "x") or Keyboard:isKeyDown("X") -- 39
end -- 38
function InputManager.prototype.yPressed(self) -- 42
	return Controller:isButtonDown(self.cid, "y") or Keyboard:isKeyDown("Y") or Keyboard:isKeyDown("Tab") -- 43
end -- 42
function InputManager.prototype.aHeld(self) -- 46
	return Controller:isButtonPressed(self.cid, "a") or anyHeld(A_KEYS) -- 47
end -- 46
function InputManager.prototype.upPressed(self) -- 50
	return Controller:isButtonDown(self.cid, "dpup") or Keyboard:isKeyDown("Up") or Keyboard:isKeyDown("W") -- 51
end -- 50
function InputManager.prototype.downPressed(self) -- 54
	return Controller:isButtonDown(self.cid, "dpdown") or Keyboard:isKeyDown("Down") or Keyboard:isKeyDown("S") -- 55
end -- 54
function InputManager.prototype.leftPressed(self) -- 58
	return Controller:isButtonDown(self.cid, "dpleft") or Keyboard:isKeyDown("Left") or Keyboard:isKeyDown("A") -- 59
end -- 58
function InputManager.prototype.rightPressed(self) -- 62
	return Controller:isButtonDown(self.cid, "dpright") or Keyboard:isKeyDown("Right") or Keyboard:isKeyDown("D") -- 63
end -- 62
function InputManager.prototype.upHeld(self) -- 66
	return Controller:isButtonPressed(self.cid, "dpup") or Keyboard:isKeyPressed("Up") or Keyboard:isKeyPressed("W") -- 67
end -- 66
function InputManager.prototype.downHeld(self) -- 70
	return Controller:isButtonPressed(self.cid, "dpdown") or Keyboard:isKeyPressed("Down") or Keyboard:isKeyPressed("S") -- 71
end -- 70
function InputManager.prototype.leftHeld(self) -- 74
	return Controller:isButtonPressed(self.cid, "dpleft") or Keyboard:isKeyPressed("Left") or Keyboard:isKeyPressed("A") -- 75
end -- 74
function InputManager.prototype.rightHeld(self) -- 78
	return Controller:isButtonPressed(self.cid, "dpright") or Keyboard:isKeyPressed("Right") or Keyboard:isKeyPressed("D") -- 79
end -- 78
function InputManager.prototype.moveX(self) -- 82
	local x = Controller:getAxis(self.cid, "leftx") -- 83
	if self:leftHeld() then -- 83
		x = x - 1 -- 84
	end -- 84
	if self:rightHeld() then -- 84
		x = x + 1 -- 85
	end -- 85
	return clamp(x, -1, 1) -- 86
end -- 82
function InputManager.prototype.moveY(self) -- 89
	local y = Controller:getAxis(self.cid, "lefty") -- 90
	if self:downHeld() then -- 90
		y = y - 1 -- 91
	end -- 91
	if self:upHeld() then -- 91
		y = y + 1 -- 92
	end -- 92
	return clamp(y, -1, 1) -- 93
end -- 89
function InputManager.prototype.l2(self) -- 96
	local v = math.max( -- 97
		0, -- 97
		Controller:getAxis(self.cid, "lefttrigger") -- 97
	) -- 97
	if Keyboard:isKeyPressed("Q") or Keyboard:isKeyPressed("L") then -- 97
		v = 1 -- 98
	end -- 98
	return clamp(v, 0, 1) -- 99
end -- 96
function InputManager.prototype.r2(self) -- 102
	local v = math.max( -- 103
		0, -- 103
		Controller:getAxis(self.cid, "righttrigger") -- 103
	) -- 103
	if Keyboard:isKeyPressed("E") or Keyboard:isKeyPressed("R") then -- 103
		v = 1 -- 104
	end -- 104
	return clamp(v, 0, 1) -- 105
end -- 102
____exports.input = __TS__New(____exports.InputManager) -- 109
return ____exports -- 109