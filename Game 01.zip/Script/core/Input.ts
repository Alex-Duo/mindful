// 输入抽象：控制器为主，键盘兜底（便于桌面调试）
import { AxisName, ButtonName, Controller, KeyName, Keyboard } from 'Dora';

function clamp(v: number, lo: number, hi: number): number {
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

function anyDown(keys: KeyName[]): boolean {
  for (let i = 0; i < keys.length; i++) {
    if (Keyboard.isKeyDown(keys[i])) return true;
  }
  return false;
}

function anyHeld(keys: KeyName[]): boolean {
  for (let i = 0; i < keys.length; i++) {
    if (Keyboard.isKeyPressed(keys[i])) return true;
  }
  return false;
}

const A_KEYS: KeyName[] = [KeyName.Return, KeyName.Z, KeyName.Space];
const B_KEYS: KeyName[] = [KeyName.Escape, KeyName.BackSpace];

export class InputManager {
  private cid = 0;

  aPressed(): boolean {
    return Controller.isButtonDown(this.cid, ButtonName.A) || anyDown(A_KEYS);
  }

  bPressed(): boolean {
    return Controller.isButtonDown(this.cid, ButtonName.B) || anyDown(B_KEYS);
  }

  xPressed(): boolean {
    return Controller.isButtonDown(this.cid, ButtonName.X) || Keyboard.isKeyDown(KeyName.X);
  }

  yPressed(): boolean {
    return Controller.isButtonDown(this.cid, ButtonName.Y) || Keyboard.isKeyDown(KeyName.Y) || Keyboard.isKeyDown(KeyName.Tab);
  }

  aHeld(): boolean {
    return Controller.isButtonPressed(this.cid, ButtonName.A) || anyHeld(A_KEYS);
  }

  upPressed(): boolean {
    return Controller.isButtonDown(this.cid, ButtonName.Up) || Keyboard.isKeyDown(KeyName.Up) || Keyboard.isKeyDown(KeyName.W);
  }

  downPressed(): boolean {
    return Controller.isButtonDown(this.cid, ButtonName.Down) || Keyboard.isKeyDown(KeyName.Down) || Keyboard.isKeyDown(KeyName.S);
  }

  leftPressed(): boolean {
    return Controller.isButtonDown(this.cid, ButtonName.Left) || Keyboard.isKeyDown(KeyName.Left) || Keyboard.isKeyDown(KeyName.A);
  }

  rightPressed(): boolean {
    return Controller.isButtonDown(this.cid, ButtonName.Right) || Keyboard.isKeyDown(KeyName.Right) || Keyboard.isKeyDown(KeyName.D);
  }

  upHeld(): boolean {
    return Controller.isButtonPressed(this.cid, ButtonName.Up) || Keyboard.isKeyPressed(KeyName.Up) || Keyboard.isKeyPressed(KeyName.W);
  }

  downHeld(): boolean {
    return Controller.isButtonPressed(this.cid, ButtonName.Down) || Keyboard.isKeyPressed(KeyName.Down) || Keyboard.isKeyPressed(KeyName.S);
  }

  leftHeld(): boolean {
    return Controller.isButtonPressed(this.cid, ButtonName.Left) || Keyboard.isKeyPressed(KeyName.Left) || Keyboard.isKeyPressed(KeyName.A);
  }

  rightHeld(): boolean {
    return Controller.isButtonPressed(this.cid, ButtonName.Right) || Keyboard.isKeyPressed(KeyName.Right) || Keyboard.isKeyPressed(KeyName.D);
  }

  moveX(): number {
    let x = Controller.getAxis(this.cid, AxisName.LeftX);
    if (this.leftHeld()) x -= 1;
    if (this.rightHeld()) x += 1;
    return clamp(x, -1, 1);
  }

  moveY(): number {
    let y = Controller.getAxis(this.cid, AxisName.LeftY);
    if (this.downHeld()) y -= 1;
    if (this.upHeld()) y += 1;
    return clamp(y, -1, 1);
  }

  l2(): number {
    let v = Math.max(0, Controller.getAxis(this.cid, AxisName.LeftTrigger));
    if (Keyboard.isKeyPressed(KeyName.Q) || Keyboard.isKeyPressed(KeyName.L)) v = 1;
    return clamp(v, 0, 1);
  }

  r2(): number {
    let v = Math.max(0, Controller.getAxis(this.cid, AxisName.RightTrigger));
    if (Keyboard.isKeyPressed(KeyName.E) || Keyboard.isKeyPressed(KeyName.R)) v = 1;
    return clamp(v, 0, 1);
  }
}

export const input = new InputManager();
