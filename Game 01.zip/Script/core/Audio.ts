// 音频系统占位：当前静音。放入对应音频文件并把 enabled 改为 true 即可启用。
import { Audio } from 'Dora';

export const Track = {
  opening: 'Audio/bgm_opening.ogg',
  stormBay: 'Audio/bgm_stormbay.ogg',
  meditation: 'Audio/bgm_meditation.ogg',
  breakdown: 'Audio/bgm_breakdown.ogg',
  sfxConfirm: 'Audio/sfx_confirm.wav',
  sfxHeal: 'Audio/sfx_heal.wav',
  sfxBreath: 'Audio/sfx_breath.wav',
} as const;

export class AudioManager {
  enabled = false;
  private currentBgm = '';

  playBgm(track: string, volume = 1, crossFade = 0.8): void {
    if (!this.enabled) return;
    if (this.currentBgm === track) {
      Audio.globalVolume = volume;
      return;
    }
    this.currentBgm = track;
    Audio.globalVolume = volume;
    Audio.playStream(track, true, crossFade);
  }

  stopBgm(fade = 1): void {
    if (!this.enabled) return;
    this.currentBgm = '';
    Audio.stopStream(fade);
  }

  playSfx(track: string): void {
    if (!this.enabled) return;
    Audio.play(track, false);
  }

  // 正念冥想 BGM 比暴风湾低 30% 音量
  playMeditationBgm(): void {
    this.playBgm(Track.meditation, 0.7);
  }

  playStormBayBgm(): void {
    this.playBgm(Track.stormBay, 1.0);
  }
}

export const audio = new AudioManager();
