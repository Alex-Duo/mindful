// @preview-file on clear
//import { setupViewport } from 'Script/core/Viewport';
//import { game } from 'Script/Game';

//setupViewport();
//game.start();
